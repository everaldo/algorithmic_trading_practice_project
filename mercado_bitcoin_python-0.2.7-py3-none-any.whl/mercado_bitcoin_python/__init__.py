"""
Mercado Bitcoin Python API Client

A comprehensive Python client for Mercado Bitcoin API with tpqoa-compatible interface.
Features intelligent caching, rate limiting, and WebSocket streaming.
"""

from .api.client import MercadoBitcoinClient
from .api.tpqoa_compatible import MBTpqoa
from .exceptions.api_exceptions import (
    MercadoBitcoinAPIError,
    RateLimitError,
    AuthenticationError,
    DataValidationError,
)

__version__ = "0.2.7"
__author__ = "Everaldo"

__all__ = [
    "MercadoBitcoinClient",
    "MBTpqoa",
    "MercadoBitcoinAPIError",
    "RateLimitError",
    "AuthenticationError",
    "DataValidationError",
]
