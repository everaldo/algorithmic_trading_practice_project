"""
tpqoa-compatible interface for Mercado Bitcoin API.

This module provides a drop-in replacement for tpqoa that works with Mercado Bitcoin,
allowing existing tpqoa-based code to work with minimal modifications.
"""

import pandas as pd
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional, Union, Tuple
from pathlib import Path
from loguru import logger
import time


from .client import MercadoBitcoinClient, MBConfig
from .websocket_client import WebSocketClient
from ..exceptions.api_exceptions import MercadoBitcoinAPIError


class MBTpqoa:
    """
    tpqoa-compatible interface for Mercado Bitcoin.

    This class provides the same interface as tpqoa.tpqoa but connects to
    Mercado Bitcoin instead of Oanda. It maintains compatibility with existing
    tpqoa-based trading code.
    """

    def __init__(self, config_file: str = None, api_key: str = None, api_secret: str = None, read_only: bool = True):
        """
        Initialize MBTpqoa client.

        Args:
            config_file: Path to configuration file (compatible with tpqoa format)
            api_key: API key (alternative to config file)
            api_secret: API secret (alternative to config file)
            read_only: If True, enables safe mode (prevents real trades)
        """
        if config_file:
            # Use config file
            self.config_file = config_file
            self.client = MercadoBitcoinClient(config_file=config_file)
        elif api_key and api_secret:
            # Use direct parameters
            self.config_file = None
            config = MBConfig(
                api_key=api_key,
                api_secret=api_secret,
                safe_mode=read_only
            )
            self.client = MercadoBitcoinClient(config=config)
        else:
            raise ValueError("Either config_file or (api_key + api_secret) must be provided")

        # WebSocket client for streaming
        self.ws_client: Optional[WebSocketClient] = None

        # Cache for instruments
        self._instruments: Optional[List[Tuple[str, str]]] = None
        self._detailed_symbols: Optional[Dict[str, List[Any]]] = None

        logger.info("MBTpqoa initialized with Mercado Bitcoin backend")

    def get_instruments(self) -> List[Tuple[str, str]]:
        """
        Get available instruments.

        Returns:
            List of tuples (display_name, symbol) compatible with tpqoa format
        """
        if self._instruments is None:
            try:
                symbols = self.client.get_symbols()
                # Convert MB symbols to tpqoa format (display_name, symbol)
                self._instruments = [
                    (self._format_instrument_name(symbol), symbol) for symbol in symbols
                ]
            except Exception as e:
                logger.error(f"Failed to get instruments: {e}")
                self._instruments = []

        return self._instruments

    def get_symbols_detailed(self, force_refresh: bool = False) -> Dict[str, List[Any]]:
        """
        Get detailed symbols information with all metadata.
        
        Returns detailed information about all available trading symbols including
        min/max volumes, prices, and trading status - format compatible with
        instrument services that need complete symbol metadata.
        
        Args:
            force_refresh: If True, bypass cache and fetch fresh data
            
        Returns:
            Dict with parallel arrays containing symbol metadata:
            {
                "symbol": ["BTC-BRL", "ETH-BRL", ...],
                "currency": ["BRL", "BRL", ...],
                "base-currency": ["BTC", "ETH", ...], 
                "exchange-traded": [True, True, ...],
                "min-volume": ["0.00001000", "0.00100000", ...],
                "max-volume": ["10.00000000", "100.00000000", ...],
                "min-price": ["1.00", "1.00", ...]
            }
        """
        if self._detailed_symbols is None or force_refresh:
            try:
                # Get raw symbols data from API
                raw_data = self.client._make_request_sync("symbols")
                
                # Handle empty response
                if not raw_data:
                    self._detailed_symbols = {
                        "symbol": [],
                        "currency": [],
                        "base-currency": [],
                        "exchange-traded": [],
                        "min-volume": [],
                        "max-volume": [],
                        "min-price": []
                    }
                else:
                    # Use raw data directly - MB API v4 already returns the correct format
                    self._detailed_symbols = {
                        "symbol": raw_data.get("symbol", []),
                        "currency": raw_data.get("currency", []),
                        "base-currency": raw_data.get("base-currency", []),
                        "exchange-traded": raw_data.get("exchange-traded", []),
                        "min-volume": raw_data.get("min-volume", []),
                        "max-volume": raw_data.get("max-volume", []),
                        "min-price": raw_data.get("min-price", [])
                    }
                    
            except Exception as e:
                logger.error(f"Failed to get detailed symbols: {e}")
                raise
                
        return self._detailed_symbols

    def _format_instrument_name(self, symbol: str) -> str:
        """
        Format instrument name for display (compatible with tpqoa).

        Args:
            symbol: MB symbol (e.g., 'BRLBTC')

        Returns:
            Formatted name (e.g., 'BTC/BRL')
        """
        # Convert MB format to tpqoa-like format
        if symbol.startswith("BRL"):
            # BRL pairs: BRLBTC -> BTC/BRL
            base = symbol[3:]
            return f"{base}/BRL"
        elif symbol.endswith("BRL"):
            # Reverse BRL pairs: BTCBRL -> BTC/BRL
            base = symbol[:-3]
            return f"{base}/BRL"
        else:
            # Other pairs: maintain original format
            return symbol

    def get_history(
        self,
        instrument: str,
        start: Union[str, datetime],
        end: Union[str, datetime],
        granularity: str,
        price: str = "M",
    ) -> pd.DataFrame:
        """
        Get historical data (tpqoa-compatible interface).

        Args:
            instrument: Trading instrument (MB symbol like 'BRLBTC')
            start: Start date (string or datetime)
            end: End date (string or datetime)
            granularity: Data granularity (M1, M5, H1, D, etc.)
            price: Price type ('M' for mid, 'B' for bid, 'A' for ask)

        Returns:
            DataFrame with OHLCV data (tpqoa-compatible columns)
        """
        # Convert tpqoa granularity to MB timeframe
        timeframe_map = {
            "M1": "1m",
            "M5": "5m",
            "M15": "15m",
            "M30": "30m",
            "H1": "1h",
            "H4": "4h",
            "D": "1d",
        }

        timeframe = timeframe_map.get(granularity)
        if not timeframe:
            raise ValueError(f"Unsupported granularity: {granularity}")

        # Convert dates to datetime objects
        if isinstance(start, str):
            start_date = pd.to_datetime(start)
        else:
            start_date = start

        if isinstance(end, str):
            end_date = pd.to_datetime(end)
        else:
            end_date = end

        # Get data from MB client
        try:
            data = self.client.get_candles(
                symbol=instrument,
                timeframe=timeframe,
                start_date=start_date,
                end_date=end_date,
            )

            if data.empty:
                logger.warning(f"No data returned for {instrument} {granularity}")
                return pd.DataFrame()

            # Convert to tpqoa-compatible format
            tpqoa_data = self._convert_to_tpqoa_format(data, price)

            logger.info(
                f"Retrieved {len(tpqoa_data)} rows for {instrument} {granularity}"
            )
            return tpqoa_data

        except Exception as e:
            logger.error(f"Failed to get history for {instrument}: {e}")
            raise

    def _convert_to_tpqoa_format(
        self, data: pd.DataFrame, price: str = "M"
    ) -> pd.DataFrame:
        """
        Convert MB OHLCV data to tpqoa format.

        Args:
            data: MB DataFrame with OHLCV columns
            price: Price type ('M' for mid, 'B' for bid, 'A' for ask)

        Returns:
            DataFrame in tpqoa format
        """
        if data.empty:
            return data

        tpqoa_data = data.copy()

        # tpqoa uses single-letter column names
        if price == "M":  # Mid prices (default)
            tpqoa_data.rename(
                columns={"open": "o", "high": "h", "low": "l", "close": "c"},
                inplace=True,
            )

        # Add volume if not present
        if "volume" not in tpqoa_data.columns:
            tpqoa_data["volume"] = 1

        # Add complete column (tpqoa convention)
        tpqoa_data["complete"] = True

        return tpqoa_data

    def get_history_for_strategy(
        self,
        instrument: str,
        start=None,
        end=None,
        granularity: str = "M5",
        countback: Optional[int] = None,
    ) -> pd.DataFrame:
        """
        Get historical data formatted for trading strategies (full column names).

        Args:
            instrument: Trading instrument (e.g., 'BTC-BRL')
            start: Start date (string or datetime) - ignored if countback is provided
            end: End date (string or datetime) - used as 'to' timestamp if countback is provided
            granularity: Data granularity (M1, M5, H1, D, etc.)
            countback: Number of periods to look back from current time or end date

        Returns:
            DataFrame with columns: open, high, low, close, volume
        """
        # Validate countback if provided
        if countback is not None:
            self._validate_countback(countback)

        # Get raw data from client (not converted to tpqoa format)
        timeframe_map = {
            "M1": "1m",
            "M5": "5m",
            "M15": "15m",
            "M30": "30m",
            "H1": "1h",
            "H3": "3h",
            "H4": "4h",
            "D": "1d",
            "W": "1w",
            "M": "1M",
        }

        timeframe = timeframe_map.get(granularity)
        if not timeframe:
            raise ValueError(f"Unsupported granularity: {granularity}")

        # Determine parameters based on countback vs start/end
        if countback is not None:
            # Use countback mode - ignore start parameter
            start_date = None
            end_date = None

            # Use end as 'to' timestamp, or current time if not provided
            if end is not None:
                if isinstance(end, str):
                    to_timestamp = int(pd.to_datetime(end).timestamp())
                else:
                    to_timestamp = int(end.timestamp())
            else:
                to_timestamp = int(time.time())
        else:
            # Use traditional start/end mode
            if isinstance(start, str):
                start_date = pd.to_datetime(start)
            else:
                start_date = start

            if isinstance(end, str):
                end_date = pd.to_datetime(end)
            else:
                end_date = end

            to_timestamp = None

        # Get data from MB client
        try:
            if countback is not None:
                # Call client with countback parameters
                data = self.client.get_candles(
                    symbol=instrument,
                    timeframe=timeframe,
                    start_date=start_date,
                    end_date=end_date,
                    countback=countback,
                    to_timestamp=to_timestamp,
                )
            else:
                # Call client with traditional parameters
                data = self.client.get_candles(
                    symbol=instrument,
                    timeframe=timeframe,
                    start_date=start_date,
                    end_date=end_date,
                )

            if data.empty:
                logger.warning(f"No data returned for {instrument} {granularity}")
                return pd.DataFrame()

            # Ensure standard column names for strategies
            strategy_data = data.copy()

            # Rename columns to standard format if needed
            column_mapping = {"o": "open", "h": "high", "l": "low", "c": "close"}

            strategy_data.rename(columns=column_mapping, inplace=True)

            # Ensure all required columns exist
            required_columns = ["open", "high", "low", "close", "volume"]
            for col in required_columns:
                if col not in strategy_data.columns:
                    if col == "volume":
                        strategy_data[col] = 1  # Default volume
                    else:
                        raise ValueError(f"Missing required column: {col}")

            logger.info(
                f"Retrieved {len(strategy_data)} rows for strategy analysis: {instrument} {granularity}"
            )
            return strategy_data[required_columns]

        except Exception as e:
            logger.error(f"Failed to get strategy data for {instrument}: {e}")
            raise

    def _validate_countback(self, countback: int) -> None:
        """
        Validate countback parameter.

        Args:
            countback: Number of periods to validate

        Raises:
            ValueError: If countback is invalid
        """
        if not isinstance(countback, int):
            raise ValueError(
                f"Invalid countback: must be integer, got {type(countback).__name__}"
            )

        if countback <= 0:
            raise ValueError(f"Invalid countback: must be positive, got {countback}")

        if countback > 5000:
            raise ValueError(
                f"Invalid countback: maximum allowed is 5000, got {countback}"
            )

    def stream_data(
        self, instrument: str, callback: callable, granularity: str = None
    ) -> None:
        """
        Stream live data (tpqoa-compatible interface).

        Args:
            instrument: Trading instrument
            callback: Function to call with new data
            granularity: Data granularity (optional, for tick data use None)
        """
        if self.ws_client is None:
            self.ws_client = WebSocketClient()

        def message_handler(data):
            """Handle WebSocket messages and convert to tpqoa format."""
            try:
                # Convert MB WebSocket data to tpqoa format
                tpqoa_data = self._convert_ws_data_to_tpqoa(data, instrument)
                if tpqoa_data:
                    callback(tpqoa_data)
            except Exception as e:
                logger.error(f"Error processing stream data: {e}")

        # Set up WebSocket client
        self.ws_client.on_message = message_handler

        # Start streaming
        import asyncio

        async def start_stream():
            try:
                await self.ws_client.connect()

                if granularity:
                    # Subscribe to candle data
                    await self.ws_client.subscribe_ticker(instrument)
                else:
                    # Subscribe to tick data
                    await self.ws_client.subscribe_trades(instrument)

                await self.ws_client.start()

            except Exception as e:
                logger.error(f"Stream error: {e}")
                if callback:
                    callback({"error": str(e)})

        # Run the stream
        asyncio.create_task(start_stream())

    def _convert_ws_data_to_tpqoa(
        self, data: Dict[str, Any], instrument: str
    ) -> Optional[Dict[str, Any]]:
        """
        Convert WebSocket data to tpqoa format.

        Args:
            data: Raw WebSocket data from MB
            instrument: Trading instrument

        Returns:
            tpqoa-compatible data dictionary
        """
        try:
            # Handle different message types
            if data.get("method") == "ticker":
                # Ticker data
                ticker_data = data.get("params", {})
                if ticker_data.get("symbol") == instrument:
                    return {
                        "type": "HEARTBEAT",
                        "time": pd.Timestamp.now(),
                        "bid": float(ticker_data.get("bid", 0)),
                        "ask": float(ticker_data.get("ask", 0)),
                        "instrument": instrument,
                    }

            elif data.get("method") == "trade":
                # Trade data
                trade_data = data.get("params", {})
                if trade_data.get("symbol") == instrument:
                    return {
                        "type": "PRICE",
                        "time": pd.to_datetime(trade_data.get("timestamp"), unit="s"),
                        "bid": float(trade_data.get("price", 0)),
                        "ask": float(trade_data.get("price", 0)),
                        "instrument": instrument,
                    }

            return None

        except Exception as e:
            logger.error(f"Error converting WebSocket data: {e}")
            return None

    def create_order(
        self, instrument: str, units: float, order_type: str = "market", **kwargs
    ) -> Dict[str, Any]:
        """
        Create a trading order (tpqoa-compatible interface).

        Args:
            instrument: Trading instrument
            units: Order size (positive for buy, negative for sell)
            order_type: Order type ('market' or 'limit')
            **kwargs: Additional order parameters

        Returns:
            Order response
        """
        try:
            # Determine side based on units
            side = "buy" if units > 0 else "sell"
            quantity = abs(units)

            # Extract price for limit orders
            price = kwargs.get("price")

            # Place order using MB client
            response = self.client.place_order(
                symbol=instrument,
                side=side,
                quantity=quantity,
                price=price,
                order_type=order_type,
            )

            # Convert to tpqoa-compatible format
            return {
                "orderCreateTransaction": {
                    "id": response.get("id"),
                    "instrument": instrument,
                    "units": str(units),
                    "type": order_type,
                    "reason": "CLIENT_ORDER",
                    "time": pd.Timestamp.now().isoformat(),
                }
            }

        except Exception as e:
            logger.error(f"Failed to create order: {e}")
            raise

    def get_account_summary(self) -> Dict[str, Any]:
        """
        Get account summary (tpqoa-compatible interface).

        Returns:
            Account information
        """
        try:
            account_info = self.client.get_account_info()

            # Convert to tpqoa-compatible format
            return {
                "account": {
                    "id": account_info.get("id", "mb_account"),
                    "currency": "BRL",
                    "balance": account_info.get("balance", 0),
                    "NAV": account_info.get("balance", 0),
                    "marginAvailable": account_info.get("available_balance", 0),
                    "openTradeCount": len(account_info.get("open_positions", [])),
                }
            }

        except Exception as e:
            logger.error(f"Failed to get account summary: {e}")
            raise

    def get_transactions(self, **kwargs) -> List[Dict[str, Any]]:
        """
        Get transaction history (tpqoa-compatible interface).

        Returns:
            List of transactions
        """
        try:
            orders = self.client.get_order_history()

            # Convert to tpqoa-compatible format
            transactions = []
            for order in orders:
                transactions.append(
                    {
                        "id": order.get("id"),
                        "type": "ORDER_FILL",
                        "instrument": order.get("symbol"),
                        "units": order.get("quantity"),
                        "price": order.get("price"),
                        "time": order.get("created_at"),
                        "accountBalance": order.get("account_balance"),
                    }
                )

            return transactions

        except Exception as e:
            logger.error(f"Failed to get transactions: {e}")
            raise

    def stop_stream(self) -> None:
        """Stop streaming data."""
        if self.ws_client:
            import asyncio

            asyncio.create_task(self.ws_client.disconnect())
            self.ws_client = None
            logger.info("Stopped data stream")


# Utility function for tpqoa compatibility
def tpqoa(config_file: str) -> MBTpqoa:
    """
    Create MBTpqoa instance (compatible with tpqoa.tpqoa constructor).

    Args:
        config_file: Path to configuration file

    Returns:
        MBTpqoa instance
    """
    return MBTpqoa(config_file)
