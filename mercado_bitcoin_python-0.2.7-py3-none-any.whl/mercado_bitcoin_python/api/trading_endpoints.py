"""
New Trading Endpoints for Mercado Bitcoin API v0.2.4
===================================================

Implementation of missing trading endpoints:
- Account information and tier
- Trading fees
- Balances and positions
- Enhanced order management

Author: Everaldo Gomes  
Date: 2025-08-08
"""

from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from loguru import logger
import pandas as pd
import time


@dataclass
class AccountInfo:
    """Account information structure."""
    account_id: str
    tier: str
    status: str
    created_at: str
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'AccountInfo':
        return cls(
            account_id=data.get('id', ''),
            tier=data.get('type', 'NORMAL'),  # Use 'type' field as tier
            status=data.get('status', 'active'),
            created_at=data.get('createdAt', '')
        )


@dataclass 
class TradingFees:
    """Trading fees structure."""
    symbol: str
    maker_fee: float
    taker_fee: float
    
    @property
    def total_fee_pct(self) -> float:
        """Total fee percentage for buy + sell cycle."""
        return (self.maker_fee + self.taker_fee) * 2  # Buy + Sell
    
    @classmethod
    def from_dict(cls, symbol: str, data: Dict[str, Any]) -> 'TradingFees':
        return cls(
            symbol=symbol,
            maker_fee=float(data.get('makerFee', 0.0)),
            taker_fee=float(data.get('takerFee', 0.0))
        )


@dataclass
class Balance:
    """Account balance structure."""
    asset: str
    available: float
    locked: float
    
    @property
    def total(self) -> float:
        return self.available + self.locked
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Balance':
        return cls(
            asset=data.get('asset', ''),
            available=float(data.get('available', 0.0)),
            locked=float(data.get('locked', 0.0))
        )


@dataclass
class Position:
    """Open position structure."""
    symbol: str
    side: str
    quantity: float
    avg_price: float
    current_price: float
    unrealized_pnl: float
    
    @property
    def is_profitable(self) -> bool:
        """Check if position is currently profitable."""
        if self.side == 'buy':
            return self.current_price > self.avg_price
        else:
            return self.current_price < self.avg_price
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Position':
        return cls(
            symbol=data.get('symbol', ''),
            side=data.get('side', ''),
            quantity=float(data.get('quantity', 0.0)),
            avg_price=float(data.get('avgPrice', 0.0)),
            current_price=float(data.get('currentPrice', 0.0)),
            unrealized_pnl=float(data.get('unrealizedPnl', 0.0))
        )


class TradingEndpointsMixin:
    """
    Mixin to add trading endpoints to MercadoBitcoinClient.
    To be merged into the main client class.
    """
    
    def get_accounts(self) -> List[AccountInfo]:
        """
        Get all accounts owned by user.
        
        Returns:
            List of AccountInfo objects
        """
        try:
            self._check_write_permission("get_accounts")
            data = self._make_request_sync("accounts", authenticated=True)
            
            accounts = []
            if isinstance(data, list):
                for account_data in data:
                    accounts.append(AccountInfo.from_dict(account_data))
            
            logger.info(f"Retrieved {len(accounts)} accounts")
            return accounts
            
        except Exception as e:
            logger.error(f"Failed to get accounts: {e}")
            raise
    
    def get_account_tier(self, account_id: str) -> str:
        """
        Get account tier information.
        
        Args:
            account_id: Account ID
            
        Returns:
            Account tier string
        """
        try:
            self._check_write_permission("get_account_tier")
            endpoint = f"accounts/{account_id}/tier"
            data = self._make_request_sync(
                endpoint=endpoint,
                method="GET",
                authenticated=True
            )
            
            # Handle array response
            if isinstance(data, list) and len(data) > 0:
                tier = data[0].get('tier', 'NORMAL')
            elif isinstance(data, dict):
                tier = data.get('tier', 'NORMAL')
            else:
                tier = 'NORMAL'
                
            logger.info(f"Account {account_id} tier: {tier}")
            return tier
            
        except Exception as e:
            logger.warning(f"Failed to get account tier for {account_id}: {e}")
            # Fallback: use account type as tier
            try:
                accounts = self.get_accounts()
                account_info = next((acc for acc in accounts if acc.account_id == account_id), None)
                fallback_tier = account_info.tier if account_info else 'NORMAL'
                logger.info(f"Using fallback tier for account {account_id}: {fallback_tier}")
                return fallback_tier
            except:
                return 'NORMAL'
    
    def get_trading_fees(self, account_id: str, symbol: str) -> TradingFees:
        """
        Get trading fees for specific symbol.
        
        Args:
            account_id: Account ID
            symbol: Trading symbol (e.g., 'SOL-BRL')
            
        Returns:
            TradingFees object
        """
        try:
            self._check_write_permission("get_trading_fees")
            endpoint = f"accounts/{account_id}/{symbol}/fees"
            data = self._make_request_sync(endpoint, authenticated=True)
            
            fees = TradingFees.from_dict(symbol, data)
            logger.info(f"Trading fees for {symbol}: maker={fees.maker_fee:.4f}%, taker={fees.taker_fee:.4f}%")
            return fees
            
        except Exception as e:
            logger.error(f"Failed to get trading fees for {symbol}: {e}")
            raise
    
    def get_balances(self, account_id: str) -> List[Balance]:
        """
        Get account balances.
        
        Args:
            account_id: Account ID
            
        Returns:
            List of Balance objects
        """
        try:
            self._check_write_permission("get_balances")
            endpoint = f"accounts/{account_id}/balances"
            data = self._make_request_sync(endpoint, authenticated=True)
            
            balances = []
            if isinstance(data, list):
                for balance_data in data:
                    balance = Balance.from_dict(balance_data)
                    if balance.total > 0:  # Only include non-zero balances
                        balances.append(balance)
            
            logger.info(f"Retrieved {len(balances)} non-zero balances")
            return balances
            
        except Exception as e:
            logger.error(f"Failed to get balances: {e}")
            raise
    
    def get_positions(self, account_id: str) -> List[Position]:
        """
        Get open positions.
        
        Args:
            account_id: Account ID
            
        Returns:
            List of Position objects
        """
        try:
            self._check_write_permission("get_positions")
            endpoint = f"accounts/{account_id}/positions"
            data = self._make_request_sync(endpoint, authenticated=True)
            
            positions = []
            if isinstance(data, list):
                for position_data in data:
                    positions.append(Position.from_dict(position_data))
            
            logger.info(f"Retrieved {len(positions)} open positions")
            return positions
            
        except Exception as e:
            logger.error(f"Failed to get positions: {e}")
            raise
    
    def place_market_order(
        self,
        account_id: str,
        symbol: str,
        side: str,  # 'buy' or 'sell'
        quantity: float,
        dry_run: bool = False
    ) -> Dict[str, Any]:
        """
        Place a market order with safety checks.
        
        Args:
            account_id: Account ID
            symbol: Trading symbol (e.g., 'SOL-BRL')
            side: 'buy' or 'sell'
            quantity: Order quantity
            dry_run: If True, don't actually place the order
            
        Returns:
            Order response data
        """
        try:
            self._check_write_permission("place_market_order")
            
            if self.config.safe_mode and not dry_run:
                logger.warning("Safe mode enabled - converting to dry run")
                dry_run = True
            
            endpoint = f"accounts/{account_id}/{symbol}/orders"
            
            order_data = {
                "side": side,
                "type": "market",
                "qty": str(quantity),
                "async": False  # Synchronous order
            }
            
            if dry_run:
                logger.info(f"DRY RUN: Would place {side} order for {quantity} {symbol}")
                return {
                    "orderId": f"dry_run_{int(time.time())}",
                    "status": "dry_run",
                    "side": side,
                    "quantity": quantity,
                    "symbol": symbol
                }
            
            data = self._make_request_sync(
                endpoint, 
                method="POST", 
                data=order_data, 
                authenticated=True
            )
            
            logger.info(f"Market order placed: {side} {quantity} {symbol}")
            return data
            
        except Exception as e:
            logger.error(f"Failed to place market order: {e}")
            raise
    
    def calculate_breakeven_price(
        self, 
        buy_price: float, 
        fees: TradingFees
    ) -> float:
        """
        Calculate breakeven price considering trading fees.
        
        Args:
            buy_price: Original buy price
            fees: TradingFees object
            
        Returns:
            Minimum sell price to breakeven
        """
        # Buy cost with fee
        buy_cost_with_fee = buy_price * (1 + fees.taker_fee / 100)
        
        # Sell price needed to recover buy cost (including sell fee)
        breakeven_price = buy_cost_with_fee / (1 - fees.maker_fee / 100)
        
        return breakeven_price
    
    def is_profitable_to_sell(
        self,
        buy_price: float,
        current_price: float,
        fees: TradingFees,
        min_profit_pct: float = 0.5  # Minimum 0.5% profit
    ) -> bool:
        """
        Check if selling at current price would be profitable.
        
        Args:
            buy_price: Original buy price
            current_price: Current market price
            fees: TradingFees object
            min_profit_pct: Minimum profit percentage required
            
        Returns:
            True if profitable to sell
        """
        breakeven_price = self.calculate_breakeven_price(buy_price, fees)
        min_profitable_price = breakeven_price * (1 + min_profit_pct / 100)
        
        return current_price >= min_profitable_price
    
    def get_account_summary(self, account_id: str, symbol: str) -> Dict[str, Any]:
        """
        Get comprehensive account summary for a specific symbol.
        
        Args:
            account_id: Account ID
            symbol: Trading symbol
            
        Returns:
            Dictionary with account summary
        """
        try:
            # Get account info
            accounts = self.get_accounts()
            account_info = next((acc for acc in accounts if acc.account_id == account_id), None)
            
            # Try to get specific tier, fallback to account info tier
            try:
                tier = self.get_account_tier(account_id)
            except:
                tier = account_info.tier if account_info else 'NORMAL'
            
            # Get trading fees
            fees = self.get_trading_fees(account_id, symbol)
            
            # Get balances
            balances = self.get_balances(account_id)
            
            # Get positions
            positions = self.get_positions(account_id)
            
            # Find relevant balances for the symbol
            base_asset = symbol.split('-')[0]  # SOL from SOL-BRL
            quote_asset = symbol.split('-')[1]  # BRL from SOL-BRL
            
            base_balance = next((b for b in balances if b.asset == base_asset), None)
            quote_balance = next((b for b in balances if b.asset == quote_asset), None)
            
            summary = {
                'account_id': account_id,
                'tier': tier,
                'symbol': symbol,
                'fees': {
                    'maker': fees.maker_fee,
                    'taker': fees.taker_fee,
                    'total_cycle': fees.total_fee_pct
                },
                'balances': {
                    base_asset: base_balance.available if base_balance else 0.0,
                    quote_asset: quote_balance.available if quote_balance else 0.0
                },
                'positions': len([p for p in positions if p.symbol == symbol])
            }
            
            return summary
            
        except Exception as e:
            logger.error(f"Failed to get account summary: {e}")
            raise