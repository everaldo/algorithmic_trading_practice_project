"""
Command-line interface for Mercado Bitcoin Python client.
"""

import click
import pandas as pd
from datetime import datetime, timedelta
from pathlib import Path
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

from .api.client import MercadoBitcoinClient, MBConfig
from .api.websocket_client import WebSocketClient
from .exceptions.api_exceptions import MercadoBitcoinAPIError

console = Console()


@click.group()
@click.option(
    "--config",
    "-c",
    default="config/mercadobitcoin.cfg",
    help="Configuration file path",
)
@click.option("--verbose", "-v", is_flag=True, help="Enable verbose logging")
@click.pass_context
def cli(ctx, config, verbose):
    """Mercado Bitcoin Python CLI"""
    ctx.ensure_object(dict)
    ctx.obj["config_file"] = config
    ctx.obj["verbose"] = verbose

    if verbose:
        import loguru

        loguru.logger.add("logs/mb_cli.log", level="DEBUG")


@cli.command()
@click.pass_context
def symbols(ctx):
    """List available trading symbols."""
    config_file = ctx.obj["config_file"]

    try:
        client = MercadoBitcoinClient(config_file=config_file)
        symbols_list = client.get_symbols()

        if not symbols_list:
            console.print("[yellow]No symbols available[/yellow]")
            return

        console.print(
            f"[bold green]Available Symbols ({len(symbols_list)}):[/bold green]"
        )

        # Display symbols in a table
        table = Table(title="Trading Symbols")
        table.add_column("Symbol", style="cyan")
        table.add_column("Description", style="green")

        for symbol in symbols_list:
            # Format description
            if symbol.startswith("BRL"):
                desc = f"{symbol[3:]}/BRL"
            elif symbol.endswith("BRL"):
                desc = f"{symbol[:-3]}/BRL"
            else:
                desc = symbol

            table.add_row(symbol, desc)

        console.print(table)

    except Exception as e:
        console.print(f"[bold red]Error: {e}[/bold red]")


@cli.command()
@click.argument("symbol")
@click.option(
    "--timeframe",
    "-t",
    default="5m",
    type=click.Choice(["1m", "5m", "15m", "30m", "1h", "4h", "1d", "1w"]),
    help="Data timeframe",
)
@click.option("--days", "-d", default=7, type=int, help="Number of days of data")
@click.option("--output", "-o", help="Output CSV file path")
@click.option("--no-cache", is_flag=True, help="Disable cache usage")
@click.pass_context
def download(ctx, symbol, timeframe, days, output, no_cache):
    """Download historical candle data."""
    config_file = ctx.obj["config_file"]

    try:
        client = MercadoBitcoinClient(config_file=config_file)

        # Calculate date range
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)

        console.print(
            Panel.fit(
                f"[bold blue]Downloading Data[/bold blue]\n"
                f"Symbol: [green]{symbol}[/green]\n"
                f"Timeframe: [green]{timeframe}[/green]\n"
                f"Period: [green]{start_date.date()} to {end_date.date()}[/green]\n"
                f"Cache: [green]{'Disabled' if no_cache else 'Enabled'}[/green]",
                title="Download Configuration",
            )
        )

        with console.status("[bold green]Downloading data..."):
            data = client.get_candles(
                symbol=symbol,
                timeframe=timeframe,
                start_date=start_date,
                end_date=end_date,
                use_cache=not no_cache,
            )

        if data.empty:
            console.print("[yellow]No data downloaded[/yellow]")
            return

        # Display summary
        console.print(f"[bold green]✓ Downloaded {len(data)} candles[/bold green]")

        # Show data preview
        table = Table(title="Data Preview (Last 5 rows)")
        table.add_column("Timestamp", style="cyan")
        table.add_column("Open", style="green")
        table.add_column("High", style="green")
        table.add_column("Low", style="red")
        table.add_column("Close", style="blue")
        table.add_column("Volume", style="yellow")

        for _, row in data.tail().iterrows():
            table.add_row(
                str(row.name),
                f"{row['open']:.4f}",
                f"{row['high']:.4f}",
                f"{row['low']:.4f}",
                f"{row['close']:.4f}",
                f"{row['volume']:.2f}",
            )

        console.print(table)

        # Save to file if specified
        if output:
            output_path = Path(output)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            data.to_csv(output_path)
            console.print(f"[green]Data saved to: {output_path}[/green]")

    except Exception as e:
        console.print(f"[bold red]Error: {e}[/bold red]")


@cli.command()
@click.pass_context
def account(ctx):
    """Show account information."""
    config_file = ctx.obj["config_file"]

    try:
        client = MercadoBitcoinClient(config_file=config_file)

        with console.status("[bold green]Getting account info..."):
            account_info = client.get_account_info()

        # Display account information
        table = Table(title="Account Information")
        table.add_column("Field", style="cyan")
        table.add_column("Value", style="green")

        for key, value in account_info.items():
            table.add_row(str(key), str(value))

        console.print(table)

    except Exception as e:
        console.print(f"[bold red]Error: {e}[/bold red]")


@cli.command()
@click.argument("symbol")
@click.option("--timeout", "-t", default=60, type=int, help="Stream timeout in seconds")
@click.pass_context
def stream(ctx, symbol, timeout):
    """Stream live data for a symbol."""
    config_file = ctx.obj["config_file"]

    console.print(f"[bold green]Starting live stream for {symbol}[/bold green]")
    console.print(f"[yellow]Press Ctrl+C to stop[/yellow]")

    try:
        import asyncio

        async def stream_data():
            ws_client = WebSocketClient()

            def on_message(data):
                console.print(
                    f"[blue]{datetime.now().strftime('%H:%M:%S')}[/blue] - {data}"
                )

            def on_connect():
                console.print("[green]Connected to WebSocket[/green]")

            def on_disconnect():
                console.print("[yellow]Disconnected from WebSocket[/yellow]")

            def on_error(error):
                console.print(f"[red]WebSocket error: {error}[/red]")

            ws_client.on_message = on_message
            ws_client.on_connect = on_connect
            ws_client.on_disconnect = on_disconnect
            ws_client.on_error = on_error

            try:
                await ws_client.connect()
                await ws_client.subscribe_ticker(symbol)

                # Run for specified timeout
                await asyncio.sleep(timeout)

            finally:
                await ws_client.disconnect()

        asyncio.run(stream_data())

    except KeyboardInterrupt:
        console.print("\n[yellow]Stream stopped by user[/yellow]")
    except Exception as e:
        console.print(f"[bold red]Stream error: {e}[/bold red]")


@cli.command()
@click.option("--symbol", "-s", help="Filter by symbol")
@click.option("--limit", "-l", default=10, type=int, help="Number of orders to show")
@click.pass_context
def orders(ctx, symbol, limit):
    """Show order history."""
    config_file = ctx.obj["config_file"]

    try:
        client = MercadoBitcoinClient(config_file=config_file)

        with console.status("[bold green]Getting order history..."):
            order_history = client.get_order_history(symbol=symbol, limit=limit)

        if not order_history:
            console.print("[yellow]No orders found[/yellow]")
            return

        # Display orders
        table = Table(title=f"Order History (Last {len(order_history)})")
        table.add_column("ID", style="cyan")
        table.add_column("Symbol", style="blue")
        table.add_column("Side", style="green")
        table.add_column("Quantity", style="yellow")
        table.add_column("Price", style="magenta")
        table.add_column("Status", style="white")

        for order in order_history:
            table.add_row(
                str(order.get("id", "")),
                str(order.get("symbol", "")),
                str(order.get("side", "")),
                str(order.get("quantity", "")),
                str(order.get("price", "")),
                str(order.get("status", "")),
            )

        console.print(table)

    except Exception as e:
        console.print(f"[bold red]Error: {e}[/bold red]")


@cli.command()
@click.pass_context
def config_template(ctx):
    """Generate configuration file template."""
    template = """[mercadobitcoin]
# Mercado Bitcoin API credentials
api_key = your_api_key_here
api_secret = your_api_secret_here

# API key type: read_only or read_write
api_key_type = read_only

# API settings (API v4)
base_url = https://api.mercadobitcoin.net/api/v4
timeout = 30

# Cache settings
enable_cache = true
cache_dir = data/cache

# Safety settings
safe_mode = true

# WebSocket settings (optional)
websocket_url = wss://ws.mercadobitcoin.net/ws
websocket_ping_interval = 4
websocket_reconnect_delay = 5
websocket_max_reconnect_attempts = 10
"""

    config_file = ctx.obj["config_file"]
    config_path = Path(config_file)

    if config_path.exists():
        if not click.confirm(
            f"Configuration file {config_file} already exists. Overwrite?"
        ):
            return

    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(template)

    console.print(f"[green]Configuration template created: {config_file}[/green]")
    console.print("[yellow]Please edit the file and add your API credentials.[/yellow]")


def main():
    """Main entry point for CLI."""
    cli()


if __name__ == "__main__":
    main()
