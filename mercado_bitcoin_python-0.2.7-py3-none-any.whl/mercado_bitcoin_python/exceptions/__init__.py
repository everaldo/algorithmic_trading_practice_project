"""
Exception classes for Mercado Bitcoin API client.
"""

from .api_exceptions import (
    MercadoBitcoinAPIError,
    RateLimitError,
    AuthenticationError,
    DataValidationError,
    WebSocketError,
)

__all__ = [
    "MercadoBitcoinAPIError",
    "RateLimitError",
    "AuthenticationError",
    "DataValidationError",
    "WebSocketError",
]
