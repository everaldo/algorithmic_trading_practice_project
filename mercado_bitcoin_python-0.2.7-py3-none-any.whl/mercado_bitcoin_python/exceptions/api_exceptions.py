"""
API exception classes for Mercado Bitcoin client.
"""


class MercadoBitcoinAPIError(Exception):
    """Base exception for Mercado Bitcoin API errors."""

    def __init__(self, message: str, status_code: int = None, response: dict = None):
        self.message = message
        self.status_code = status_code
        self.response = response
        super().__init__(self.message)


class RateLimitError(MercadoBitcoinAPIError):
    """Raised when API rate limit is exceeded."""

    pass


class AuthenticationError(MercadoBitcoinAPIError):
    """Raised when API authentication fails."""

    pass


class DataValidationError(MercadoBitcoinAPIError):
    """Raised when data validation fails."""

    pass


class WebSocketError(Exception):
    """Raised when WebSocket connection fails."""

    pass


class CacheError(Exception):
    """Raised when cache operations fail."""

    pass
