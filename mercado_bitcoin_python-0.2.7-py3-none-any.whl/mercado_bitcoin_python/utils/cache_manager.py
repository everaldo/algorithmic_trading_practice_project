"""
Intelligent cache manager with timeframe-based storage strategy.

Based on user requirements:
- 1m: 1 arquivo/dia
- 5m: 1 arquivo/mês
- 15m: 1 arquivo/mês
- 1h: 1 arquivo/mês
- 1d: 1 arquivo/ano
- 1w: 10 anos/arquivo
"""

import os
import pandas as pd
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, Optional, Literal, Tuple
from dataclasses import dataclass
from loguru import logger

from ..exceptions.api_exceptions import CacheError

Timeframe = Literal["1m", "5m", "15m", "30m", "1h", "3h", "4h", "1d", "1w", "1M"]

CACHE_STRATEGY = {
    "1m": {"group_by": "day", "files_per_group": 1},  # 1 arquivo/dia
    "5m": {"group_by": "month", "files_per_group": 1},  # 1 arquivo/mês
    "15m": {"group_by": "month", "files_per_group": 1},  # 1 arquivo/mês
    "30m": {"group_by": "month", "files_per_group": 1},  # 1 arquivo/mês
    "1h": {"group_by": "month", "files_per_group": 1},  # 1 arquivo/mês
    "3h": {"group_by": "month", "files_per_group": 1},  # 1 arquivo/mês (nativo da API)
    "4h": {"group_by": "month", "files_per_group": 1},  # 1 arquivo/mês
    "1d": {"group_by": "year", "files_per_group": 1},  # 1 arquivo/ano
    "1w": {"group_by": "decade", "files_per_group": 1},  # 10 anos/arquivo
    "1M": {"group_by": "decade", "files_per_group": 1},  # 10 anos/arquivo (nativo da API)
}


@dataclass
class CacheConfig:
    """Configuration for cache management."""

    base_dir: Path = Path("data/cache")
    max_file_size_mb: int = 100
    enable_compression: bool = True
    validate_on_load: bool = True


class CacheManager:
    """
    Intelligent cache manager for market data with timeframe-based storage.

    Features:
    - Timeframe-specific file organization
    - Intelligent resume functionality
    - Data validation and integrity checks
    - Automatic file compression
    """

    def __init__(self, config: CacheConfig = None):
        """
        Initialize cache manager.

        Args:
            config: Cache configuration
        """
        self.config = config or CacheConfig()
        self.base_dir = Path(self.config.base_dir)
        self.base_dir.mkdir(parents=True, exist_ok=True)

        logger.info(f"Cache manager initialized with base dir: {self.base_dir}")

    def _get_file_path(
        self, symbol: str, timeframe: Timeframe, timestamp: datetime
    ) -> Path:
        """
        Get cache file path based on timeframe strategy.

        Args:
            symbol: Trading symbol (e.g., 'BRLBTC')
            timeframe: Data timeframe
            timestamp: Data timestamp

        Returns:
            Path to cache file
        """
        strategy = CACHE_STRATEGY.get(timeframe)
        if not strategy:
            raise CacheError(f"Unsupported timeframe: {timeframe}")

        group_by = strategy["group_by"]

        # Create directory structure: base_dir/symbol/timeframe/
        symbol_dir = self.base_dir / symbol / timeframe
        symbol_dir.mkdir(parents=True, exist_ok=True)

        # Generate filename based on grouping strategy
        if group_by == "day":
            filename = f"{symbol}_{timeframe}_{timestamp.strftime('%Y_%m_%d')}.csv"
        elif group_by == "month":
            filename = f"{symbol}_{timeframe}_{timestamp.strftime('%Y_%m')}.csv"
        elif group_by == "year":
            filename = f"{symbol}_{timeframe}_{timestamp.strftime('%Y')}.csv"
        elif group_by == "decade":
            decade = (timestamp.year // 10) * 10
            filename = f"{symbol}_{timeframe}_{decade}s.csv"
        else:
            raise CacheError(f"Unsupported grouping strategy: {group_by}")

        return symbol_dir / filename

    def _get_date_range_for_file(
        self, symbol: str, timeframe: Timeframe, timestamp: datetime
    ) -> Tuple[datetime, datetime]:
        """
        Get the date range that should be covered by a cache file.

        Args:
            symbol: Trading symbol
            timeframe: Data timeframe
            timestamp: Reference timestamp

        Returns:
            Tuple of (start_date, end_date) for the file
        """
        strategy = CACHE_STRATEGY.get(timeframe)
        group_by = strategy["group_by"]

        if group_by == "day":
            start_date = timestamp.replace(hour=0, minute=0, second=0, microsecond=0)
            end_date = start_date + timedelta(days=1)
        elif group_by == "month":
            start_date = timestamp.replace(
                day=1, hour=0, minute=0, second=0, microsecond=0
            )
            if start_date.month == 12:
                end_date = start_date.replace(year=start_date.year + 1, month=1)
            else:
                end_date = start_date.replace(month=start_date.month + 1)
        elif group_by == "year":
            start_date = timestamp.replace(
                month=1, day=1, hour=0, minute=0, second=0, microsecond=0
            )
            end_date = start_date.replace(year=start_date.year + 1)
        elif group_by == "decade":
            decade_start = (timestamp.year // 10) * 10
            start_date = datetime(decade_start, 1, 1)
            end_date = datetime(decade_start + 10, 1, 1)
        else:
            raise CacheError(f"Unsupported grouping strategy: {group_by}")

        return start_date, end_date

    def get_cached_data(
        self,
        symbol: str,
        timeframe: Timeframe,
        start_date: datetime,
        end_date: datetime,
    ) -> Optional[pd.DataFrame]:
        """
        Retrieve cached data for the specified range.

        Args:
            symbol: Trading symbol
            timeframe: Data timeframe
            start_date: Start date for data
            end_date: End date for data

        Returns:
            Cached DataFrame or None if not available
        """
        try:
            # Find all cache files that might contain data in the range
            cache_files = []
            current_date = start_date

            while current_date < end_date:
                file_path = self._get_file_path(symbol, timeframe, current_date)
                if file_path.exists():
                    cache_files.append(file_path)

                # Move to next period based on grouping strategy
                strategy = CACHE_STRATEGY.get(timeframe)
                group_by = strategy["group_by"]

                if group_by == "day":
                    current_date += timedelta(days=1)
                elif group_by == "month":
                    if current_date.month == 12:
                        current_date = current_date.replace(
                            year=current_date.year + 1, month=1
                        )
                    else:
                        current_date = current_date.replace(
                            month=current_date.month + 1
                        )
                elif group_by == "year":
                    current_date = current_date.replace(year=current_date.year + 1)
                elif group_by == "decade":
                    current_date = current_date.replace(year=current_date.year + 10)

            if not cache_files:
                logger.debug(f"No cache files found for {symbol} {timeframe}")
                return None

            # Load and combine data from all files
            dataframes = []
            for file_path in cache_files:
                try:
                    df = pd.read_csv(file_path, index_col="timestamp", parse_dates=True)
                    dataframes.append(df)
                    logger.debug(f"Loaded cache file: {file_path} ({len(df)} rows)")
                except Exception as e:
                    logger.warning(f"Failed to load cache file {file_path}: {e}")
                    continue

            if not dataframes:
                return None

            # Combine all dataframes
            combined_df = pd.concat(dataframes)
            combined_df.sort_index(inplace=True)

            # Filter to requested date range
            mask = (combined_df.index >= start_date) & (combined_df.index <= end_date)
            filtered_df = combined_df[mask]

            if self.config.validate_on_load:
                self._validate_data(filtered_df, symbol, timeframe)

            logger.info(
                f"Retrieved {len(filtered_df)} cached rows for {symbol} {timeframe}"
            )
            return filtered_df

        except Exception as e:
            logger.error(f"Error retrieving cached data: {e}")
            return None

    def save_data(self, data: pd.DataFrame, symbol: str, timeframe: Timeframe) -> bool:
        """
        Save data to cache with intelligent file organization.

        Args:
            data: DataFrame to cache
            symbol: Trading symbol
            timeframe: Data timeframe

        Returns:
            True if successful, False otherwise
        """
        if data.empty:
            logger.warning("Cannot cache empty DataFrame")
            return False

        try:
            # Group data by file periods
            data_groups = self._group_data_by_period(data, timeframe)

            for period_start, period_data in data_groups.items():
                file_path = self._get_file_path(symbol, timeframe, period_start)

                # Check if file already exists and merge if needed
                if file_path.exists():
                    try:
                        existing_data = pd.read_csv(
                            file_path, index_col="timestamp", parse_dates=True
                        )
                        # Combine and remove duplicates
                        combined_data = pd.concat([existing_data, period_data])
                        combined_data = combined_data[
                            ~combined_data.index.duplicated(keep="last")
                        ]
                        combined_data.sort_index(inplace=True)
                    except Exception as e:
                        logger.warning(
                            f"Failed to merge with existing file {file_path}: {e}"
                        )
                        combined_data = period_data
                else:
                    combined_data = period_data

                # Save to file
                combined_data.to_csv(file_path)
                logger.debug(f"Saved {len(combined_data)} rows to {file_path}")

            logger.info(
                f"Successfully cached {len(data)} rows for {symbol} {timeframe}"
            )
            return True

        except Exception as e:
            logger.error(f"Error saving data to cache: {e}")
            return False

    def _group_data_by_period(
        self, data: pd.DataFrame, timeframe: Timeframe
    ) -> Dict[datetime, pd.DataFrame]:
        """
        Group data by cache file periods.

        Args:
            data: DataFrame to group
            timeframe: Data timeframe

        Returns:
            Dictionary mapping period start dates to DataFrames
        """
        groups = {}

        for timestamp in data.index:
            file_start, file_end = self._get_date_range_for_file(
                "", timeframe, timestamp
            )

            if file_start not in groups:
                groups[file_start] = pd.DataFrame()

            # Add this row to the appropriate group
            row_data = data.loc[[timestamp]]
            if groups[file_start].empty:
                groups[file_start] = row_data
            else:
                groups[file_start] = pd.concat([groups[file_start], row_data])

        return groups

    def get_latest_timestamp(
        self, symbol: str, timeframe: Timeframe
    ) -> Optional[datetime]:
        """
        Get the latest timestamp for cached data.

        Args:
            symbol: Trading symbol
            timeframe: Data timeframe

        Returns:
            Latest timestamp or None if no data exists
        """
        try:
            symbol_dir = self.base_dir / symbol / timeframe
            if not symbol_dir.exists():
                return None

            # Find all cache files for this symbol/timeframe
            cache_files = list(symbol_dir.glob("*.csv"))
            if not cache_files:
                return None

            latest_timestamp = None

            for file_path in cache_files:
                try:
                    df = pd.read_csv(file_path, index_col="timestamp", parse_dates=True)
                    if not df.empty:
                        file_latest = df.index.max()
                        if latest_timestamp is None or file_latest > latest_timestamp:
                            latest_timestamp = file_latest
                except Exception as e:
                    logger.warning(f"Error reading cache file {file_path}: {e}")
                    continue

            return latest_timestamp

        except Exception as e:
            logger.error(f"Error getting latest timestamp: {e}")
            return None

    def _validate_data(self, data: pd.DataFrame, symbol: str, timeframe: str) -> bool:
        """
        Validate cached data integrity.

        Args:
            data: DataFrame to validate
            symbol: Trading symbol
            timeframe: Data timeframe

        Returns:
            True if valid, raises exception if invalid
        """
        if data.empty:
            raise CacheError("Data is empty")

        # Check required columns
        required_columns = ["open", "high", "low", "close", "volume"]
        missing_columns = [col for col in required_columns if col not in data.columns]
        if missing_columns:
            raise CacheError(f"Missing columns: {missing_columns}")

        # Check for OHLC consistency
        invalid_ohlc = (
            (data["high"] < data["low"])
            | (data["high"] < data["open"])
            | (data["high"] < data["close"])
            | (data["low"] > data["open"])
            | (data["low"] > data["close"])
        )

        if invalid_ohlc.any():
            logger.warning(
                f"Found {invalid_ohlc.sum()} rows with invalid OHLC relationships"
            )

        return True

    def clear_cache(self, symbol: str = None, timeframe: Timeframe = None) -> bool:
        """
        Clear cache files.

        Args:
            symbol: Specific symbol to clear (None for all)
            timeframe: Specific timeframe to clear (None for all)

        Returns:
            True if successful
        """
        try:
            if symbol and timeframe:
                # Clear specific symbol/timeframe
                cache_dir = self.base_dir / symbol / timeframe
                if cache_dir.exists():
                    for file_path in cache_dir.glob("*.csv"):
                        file_path.unlink()
                    logger.info(f"Cleared cache for {symbol} {timeframe}")
            elif symbol:
                # Clear all timeframes for symbol
                symbol_dir = self.base_dir / symbol
                if symbol_dir.exists():
                    for file_path in symbol_dir.rglob("*.csv"):
                        file_path.unlink()
                    logger.info(f"Cleared all cache for {symbol}")
            else:
                # Clear all cache
                for file_path in self.base_dir.rglob("*.csv"):
                    file_path.unlink()
                logger.info("Cleared all cache")

            return True

        except Exception as e:
            logger.error(f"Error clearing cache: {e}")
            return False
