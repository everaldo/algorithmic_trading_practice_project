"""
Main REST API client for Mercado Bitcoin with intelligent caching.
"""

import os
import hmac
import hashlib
import time
import requests
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Literal
from pathlib import Path
from loguru import logger
from dataclasses import dataclass

from ..utils.cache_manager import CacheManager, CacheConfig
from ..utils.rate_limiter import RateLimiter
from ..utils.data_validator import DataValidator
from ..exceptions.api_exceptions import (
    MercadoBitcoinAPIError,
    RateLimitError,
    AuthenticationError,
    DataValidationError,
)
from .trading_endpoints import TradingEndpointsMixin

APIKeyType = Literal["read_only", "read_write"]
# Native MB API resolutions: 1m, 15m, 1h, 3h, 1d, 1w, 1M
# Interpolated resolutions: 5m, 30m, 4h (derived from native data)
Timeframe = Literal["1m", "5m", "15m", "30m", "1h", "3h", "4h", "1d", "1w", "1M"]


@dataclass
class MBConfig:
    """Configuration for Mercado Bitcoin API client."""

    api_key: str
    api_secret: str
    api_key_type: APIKeyType = "read_only"
    base_url: str = "https://api.mercadobitcoin.net/api/v4"
    timeout: int = 30
    enable_cache: bool = True
    cache_dir: str = "data/cache"
    safe_mode: bool = True


class MercadoBitcoinClient(TradingEndpointsMixin):
    """
    Main REST API client for Mercado Bitcoin.

    Features:
    - Intelligent caching with timeframe-based storage
    - Rate limiting (1 req/s)
    - API key type validation (read-only vs read-write)
    - Safe mode for development
    - Data validation and integrity checks
    - Trading endpoints (account info, fees, positions, orders)
    """

    def __init__(self, config: MBConfig = None, config_file: str = None):
        """
        Initialize Mercado Bitcoin client.

        Args:
            config: Configuration object
            config_file: Path to configuration file (alternative to config object)
        """
        if config_file:
            self.config = self._load_config_from_file(config_file)
        elif config:
            self.config = config
        else:
            raise ValueError("Either config or config_file must be provided")

        # Initialize components
        self.rate_limiter = RateLimiter(
            requests_per_minute=500
        )  # 500 req/min total limit

        if self.config.enable_cache:
            cache_config = CacheConfig(base_dir=Path(self.config.cache_dir))
            self.cache_manager = CacheManager(cache_config)
        else:
            self.cache_manager = None

        self.validator = DataValidator()

        # API endpoints
        self.base_url = self.config.base_url
        self.session = requests.Session()
        self.session.timeout = self.config.timeout

        # Available symbols (will be populated on first call)
        self._symbols: Optional[List[str]] = None
        
        # Bearer token authentication
        self._access_token: Optional[str] = None
        self._token_expiration: Optional[int] = None

        logger.info(
            f"MercadoBitcoin client initialized (key_type: {self.config.api_key_type}, safe_mode: {self.config.safe_mode})"
        )

    def _get_access_token(self) -> str:
        """
        Get a valid access token, refreshing if necessary.
        
        Returns:
            Valid access token
        """
        current_time = int(time.time())
        
        # Check if token needs refresh (5 minutes before expiration)
        if (
            not self._access_token 
            or not self._token_expiration 
            or current_time >= (self._token_expiration - 300)
        ):
            self._refresh_access_token()
            
        return self._access_token

    def _refresh_access_token(self) -> None:
        """
        Obtain a new access token from the /authorize endpoint.
        """
        auth_url = f"{self.base_url}/authorize"
        auth_payload = {
            "login": self.config.api_key,
            "password": self.config.api_secret
        }
        
        try:
            response = self.session.post(
                auth_url,
                json=auth_payload,
                headers={"Content-Type": "application/json"}
            )
            response.raise_for_status()
            
            auth_data = response.json()
            
            if "access_token" not in auth_data:
                raise AuthenticationError("No access token in response")
                
            self._access_token = auth_data["access_token"]
            self._token_expiration = auth_data.get("expiration")
            
            logger.info(f"Access token refreshed, expires at: {self._token_expiration}")
            
        except requests.exceptions.RequestException as e:
            raise AuthenticationError(f"Failed to obtain access token: {e}")

    def _load_config_from_file(self, config_file: str) -> MBConfig:
        """Load configuration from file."""
        from configparser import ConfigParser

        config_path = Path(config_file)
        if not config_path.exists():
            raise FileNotFoundError(f"Configuration file not found: {config_file}")

        parser = ConfigParser()
        parser.read(config_file)

        try:
            section = parser["mercadobitcoin"]
            return MBConfig(
                api_key=section["api_key"],
                api_secret=section["api_secret"],
                api_key_type=section.get("api_key_type", "read_only"),
                base_url=section.get(
                    "base_url", "https://api.mercadobitcoin.net/api/v4"
                ),
                timeout=int(section.get("timeout", "30")),
                enable_cache=section.getboolean("enable_cache", True),
                cache_dir=section.get("cache_dir", "data/cache"),
                safe_mode=section.getboolean("safe_mode", True),
            )
        except KeyError as e:
            raise ValueError(f"Missing configuration key: {e}")

    def _check_write_permission(self, operation: str) -> None:
        """
        Check if current API key has write permissions for the operation.

        Args:
            operation: Description of the operation requiring write access

        Raises:
            AuthenticationError: If operation requires write access but key is read-only
        """
        if self.config.api_key_type == "read_only":
            raise AuthenticationError(
                f"Operation '{operation}' requires read-write API key, "
                f"but current key is read-only. Set api_key_type='read_write' "
                f"in configuration if you have write permissions."
            )

        if self.config.safe_mode:
            logger.warning(
                f"SAFE MODE: Would perform write operation '{operation}' "
                f"but safe_mode is enabled. Set safe_mode=False to execute."
            )
            return

        logger.info(f"Write operation authorized: {operation}")

    def _generate_signature(self, endpoint: str, params: Dict[str, Any]) -> str:
        """Generate HMAC signature for authenticated requests."""
        # Create query string
        query_string = "&".join([f"{k}={v}" for k, v in sorted(params.items())])
        message = f"{endpoint}?{query_string}"

        # Generate signature
        signature = hmac.new(
            self.config.api_secret.encode(), message.encode(), hashlib.sha256
        ).hexdigest()

        return signature

    async def _make_request(
        self, endpoint: str, params: Dict[str, Any] = None, authenticated: bool = False
    ) -> Dict[str, Any]:
        """
        Make API request with rate limiting.

        Args:
            endpoint: API endpoint
            params: Request parameters
            authenticated: Whether request requires authentication

        Returns:
            API response data
        """
        # Apply endpoint-specific rate limiting
        await self.rate_limiter.acquire(endpoint)

        params = params or {}
        url = f"{self.base_url}/{endpoint}"

        headers = {}

        if authenticated:
            # Add Bearer token authentication
            token = self._get_access_token()
            headers["Authorization"] = f"Bearer {token}"

        try:
            response = self.session.get(url, params=params, headers=headers)
            response.raise_for_status()

            data = response.json()

            # Check for API-level errors
            if "error_message" in data:
                raise MercadoBitcoinAPIError(
                    data["error_message"],
                    status_code=response.status_code,
                    response=data,
                )

            return data

        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 429:
                raise RateLimitError("Rate limit exceeded", status_code=429)
            elif e.response.status_code in [401, 403]:
                raise AuthenticationError(
                    "Authentication failed", status_code=e.response.status_code
                )
            else:
                raise MercadoBitcoinAPIError(
                    f"HTTP error: {e}", status_code=e.response.status_code
                )
        except requests.exceptions.RequestException as e:
            raise MercadoBitcoinAPIError(f"Request failed: {e}")

    def _make_request_sync(
        self, 
        endpoint: str, 
        method: str = "GET",
        params: Dict[str, Any] = None, 
        data: Dict[str, Any] = None,
        authenticated: bool = False
    ) -> Dict[str, Any]:
        """Synchronous version of _make_request with POST support."""
        # Apply endpoint-specific rate limiting
        self.rate_limiter.acquire_sync(endpoint)

        params = params or {}
        data = data or {}
        url = f"{self.base_url}/{endpoint}"

        headers = {}

        if authenticated:
            # Add Bearer token authentication
            token = self._get_access_token()
            headers["Authorization"] = f"Bearer {token}"

        # Add Content-Type for POST requests
        if method.upper() == "POST":
            headers["Content-Type"] = "application/json"

        try:
            if method.upper() == "POST":
                response = self.session.post(url, json=data, headers=headers)
            else:
                response = self.session.get(url, params=params, headers=headers)
                
            response.raise_for_status()

            data = response.json()

            # Check for API-level errors
            if "error_message" in data:
                raise MercadoBitcoinAPIError(
                    data["error_message"],
                    status_code=response.status_code,
                    response=data,
                )

            return data

        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 429:
                raise RateLimitError("Rate limit exceeded", status_code=429)
            elif e.response.status_code in [401, 403]:
                raise AuthenticationError(
                    "Authentication failed", status_code=e.response.status_code
                )
            else:
                raise MercadoBitcoinAPIError(
                    f"HTTP error: {e}", status_code=e.response.status_code
                )
        except requests.exceptions.RequestException as e:
            raise MercadoBitcoinAPIError(f"Request failed: {e}")

    def get_symbols(self) -> List[str]:
        """
        Get list of available trading symbols.

        Returns:
            List of symbol strings (e.g., ['BRLBTC', 'BRLETH', ...])
        """
        if self._symbols is None:
            try:
                data = self._make_request_sync("symbols")

                # Handle Mercado Bitcoin API v4 response format
                if isinstance(data, dict) and "symbol" in data:
                    # MB API v4 format: {"symbol": ["BTC-BRL", ...], "description": [...], "currency": [...]}
                    self._symbols = data["symbol"]
                elif isinstance(data, list):
                    # If data is a list directly
                    self._symbols = [symbol.get("symbol", symbol) for symbol in data]
                elif isinstance(data, dict):
                    # If data is a dict with symbols key
                    symbols_data = data.get("symbols", data.get("data", []))
                    if isinstance(symbols_data, list):
                        self._symbols = [
                            symbol.get("symbol", symbol) for symbol in symbols_data
                        ]
                    else:
                        logger.warning(
                            f"Unexpected symbols data format: {symbols_data}"
                        )
                        self._symbols = []
                else:
                    logger.warning(f"Unexpected response format: {type(data)}")
                    self._symbols = []

                logger.info(f"Retrieved {len(self._symbols)} available symbols")
            except Exception as e:
                logger.error(f"Failed to get symbols: {e}")
                self._symbols = []

        return self._symbols

    def get_candles(
        self,
        symbol: str,
        timeframe: Timeframe,
        start_date: datetime = None,
        end_date: datetime = None,
        use_cache: bool = True,
        countback: Optional[int] = None,
        to_timestamp: Optional[int] = None,
    ) -> pd.DataFrame:
        """
        Get historical candle data with intelligent caching.

        Args:
            symbol: Trading symbol (e.g., 'BRLBTC')
            timeframe: Data timeframe
            start_date: Start date for data (ignored if countback provided)
            end_date: End date for data (ignored if countback provided)
            use_cache: Whether to use cached data
            countback: Number of periods to look back from to_timestamp
            to_timestamp: End timestamp for countback mode (uses current time if None)

        Returns:
            DataFrame with OHLCV data
        """
        # Validate countback if provided (even if None in kwargs)
        if "countback" in locals() and countback is not None:
            self._validate_countback(countback)

        # Handle countback mode vs traditional start/end mode
        if countback is not None:
            # Countback mode - always fetch fresh data, ignore cache
            import time

            if to_timestamp is None:
                to_timestamp = int(time.time())

            logger.info(
                f"Getting {countback} candles for {symbol} {timeframe} ending at timestamp {to_timestamp}"
            )
            return self._fetch_candles_with_countback(
                symbol, timeframe, countback, to_timestamp
            )

        # Traditional start/end mode
        # Set default dates if not provided
        if end_date is None:
            end_date = datetime.now()
        if start_date is None:
            start_date = end_date - timedelta(days=30)

        logger.info(
            f"Getting candles for {symbol} {timeframe} from {start_date} to {end_date}"
        )

        # Expand date range to cover complete months for better caching
        expanded_start = self._expand_start_date_to_month_start(start_date)
        expanded_end = self._expand_end_date_to_month_end(end_date)

        # Try to get data from cache first
        cached_data = None
        if use_cache and self.cache_manager:
            cached_data = self.cache_manager.get_cached_data(
                symbol, timeframe, expanded_start, expanded_end
            )

            if cached_data is not None and not cached_data.empty:
                # Check if we have complete coverage for the EXPANDED range
                cache_start = cached_data.index.min()
                cache_end = cached_data.index.max()

                # Validate cache completeness with stricter criteria
                if self._is_cache_complete(
                    cached_data, expanded_start, expanded_end, timeframe
                ):
                    logger.info(f"Using complete cached data: {len(cached_data)} rows")
                    # Filter to original requested range
                    mask = (cached_data.index >= start_date) & (
                        cached_data.index <= end_date
                    )
                    filtered_data = cached_data[mask]
                    logger.info(
                        f"Returning {len(filtered_data)} candles for requested range"
                    )
                    return filtered_data
                else:
                    logger.warning(
                        f"Cache incomplete or invalid, clearing and re-downloading"
                    )
                    # Clear invalid cache to force complete re-download
                    self.cache_manager.clear_cache(symbol, timeframe)
                    cached_data = None

        # Fetch complete data from API (using expanded range for better caching)
        new_data = self._fetch_candles_from_api(
            symbol, timeframe, expanded_start, expanded_end
        )

        # Use only new data from API (no combining with partial cache)
        if not new_data.empty:
            combined_data = new_data
        else:
            combined_data = pd.DataFrame()

        # Cache the new data ONLY if it represents a complete period
        if not new_data.empty and self.cache_manager:
            if self._is_data_complete_for_caching(
                new_data, expanded_start, expanded_end, timeframe
            ):
                logger.info(f"Caching complete dataset: {len(new_data)} rows")
                self.cache_manager.save_data(new_data, symbol, timeframe)
            else:
                logger.warning(
                    f"Dataset incomplete, NOT caching to avoid partial cache"
                )

        # Validate final data
        if not combined_data.empty:
            self.validator.validate_ohlcv_data(combined_data, symbol, strict=False)

        # Filter to original requested range
        if not combined_data.empty:
            mask = (combined_data.index >= start_date) & (
                combined_data.index <= end_date
            )
            filtered_data = combined_data[mask]
            logger.info(
                f"Returning {len(filtered_data)} candles for {symbol} {timeframe}"
            )
            return filtered_data

        logger.info(f"Returning empty dataset for {symbol} {timeframe}")
        return combined_data

    def _fetch_candles_from_api(
        self,
        symbol: str,
        timeframe: Timeframe,
        start_date: datetime,
        end_date: datetime,
    ) -> pd.DataFrame:
        """
        Fetch candle data directly from API.

        Args:
            symbol: Trading symbol
            timeframe: Data timeframe
            start_date: Start date
            end_date: End date

        Returns:
            DataFrame with OHLCV data
        """
        try:
            # Check if timeframe needs interpolation
            native_timeframes = ["1m", "15m", "1h", "3h", "1d", "1w", "1M"]
            interpolated_timeframes = {
                "5m": ("1m", 5),  # 5m from 1m data
                "30m": ("15m", 2),  # 30m from 15m data
                "4h": ("1h", 4),  # 4h from 1h data
            }

            if timeframe in interpolated_timeframes:
                # Use interpolation for non-native timeframes
                source_tf, multiplier = interpolated_timeframes[timeframe]
                logger.info(
                    f"Using interpolation: {timeframe} from {source_tf} data (factor: {multiplier})"
                )

                # Fetch more data to ensure we have enough for interpolation
                extended_start = start_date - timedelta(
                    hours=multiplier * 24
                )  # Extra buffer
                raw_data = self._fetch_native_candles(
                    symbol, source_tf, extended_start, end_date
                )

                if raw_data.empty:
                    return pd.DataFrame()

                # Apply interpolation
                return self._interpolate_candles(
                    raw_data, timeframe, start_date, end_date
                )

            elif timeframe in native_timeframes:
                # Direct API call for native timeframes
                return self._fetch_native_candles(
                    symbol, timeframe, start_date, end_date
                )

            else:
                raise ValueError(f"Unsupported timeframe: {timeframe}")

        except Exception as e:
            logger.error(f"Failed to fetch candles from API: {e}")
            return pd.DataFrame()

    def _fetch_native_candles(
        self, symbol: str, timeframe: str, start_date: datetime, end_date: datetime
    ) -> pd.DataFrame:
        """
        Fetch candle data directly from MB API for native timeframes.
        """
        try:
            # MB API timeframe mapping
            api_timeframe_map = {
                "1m": "1m",
                "15m": "15m",
                "1h": "1h",
                "3h": "3h",
                "1d": "1d",
                "1w": "1w",
                "1M": "1M",
            }

            api_timeframe = api_timeframe_map.get(timeframe)
            if not api_timeframe:
                raise ValueError(f"Non-native timeframe: {timeframe}")

            params = {
                "symbol": symbol,
                "resolution": api_timeframe,
                "from": int(start_date.timestamp()),
                "to": int(end_date.timestamp()),
            }

            data = self._make_request_sync(
                endpoint="candles",
                method="GET", 
                params=params,
                authenticated=False
            )

            # Handle Mercado Bitcoin API v4 candles format
            # Format: {'t': [timestamps], 'o': [opens], 'h': [highs], 'l': [lows], 'c': [closes], 'v': [volumes]}
            if isinstance(data, dict) and all(
                key in data for key in ["t", "o", "h", "l", "c", "v"]
            ):
                timestamps = data.get("t", [])
                if not timestamps:
                    logger.warning(f"No candle data returned for {symbol} {timeframe}")
                    return pd.DataFrame()

                # Create DataFrame from individual arrays
                df = pd.DataFrame(
                    {
                        "timestamp": timestamps,
                        "open": data.get("o", []),
                        "high": data.get("h", []),
                        "low": data.get("l", []),
                        "close": data.get("c", []),
                        "volume": data.get("v", []),
                    }
                )
            else:
                # Fallback to original format
                candles = data.get("candles", [])
                if not candles:
                    logger.warning(f"No candle data returned for {symbol} {timeframe}")
                    return pd.DataFrame()

                df = pd.DataFrame(candles)

            # Standardize column names and types
            df["timestamp"] = pd.to_datetime(df["timestamp"], unit="s")
            df.set_index("timestamp", inplace=True)

            # Ensure numeric columns
            numeric_columns = ["open", "high", "low", "close", "volume"]
            for col in numeric_columns:
                if col in df.columns:
                    df[col] = pd.to_numeric(df[col], errors="coerce")

            # Clean and validate data
            df = self.validator.clean_data(df)

            logger.info(
                f"Fetched {len(df)} native candles from API for {symbol} {timeframe}"
            )
            return df

        except Exception as e:
            logger.error(f"Failed to fetch native candles from API: {e}")
            return pd.DataFrame()

    def place_order(
        self,
        symbol: str,
        side: str,
        quantity: float,
        price: float = None,
        order_type: str = "market",
    ) -> Dict[str, Any]:
        """
        Place a trading order.

        Args:
            symbol: Trading symbol
            side: 'buy' or 'sell'
            quantity: Order quantity
            price: Order price (for limit orders)
            order_type: 'market' or 'limit'

        Returns:
            Order response data
        """
        self._check_write_permission(f"place {side} order for {quantity} {symbol}")

        if self.config.safe_mode:
            return {
                "message": "SAFE MODE: Order not executed",
                "symbol": symbol,
                "side": side,
                "quantity": quantity,
                "price": price,
                "type": order_type,
            }

        params = {
            "symbol": symbol,
            "side": side,
            "quantity": str(quantity),
            "type": order_type,
        }

        if order_type == "limit" and price:
            params["price"] = str(price)

        try:
            data = self._make_request_sync("order", params, authenticated=True)
            logger.info(f"Order placed: {data}")
            return data
        except Exception as e:
            logger.error(f"Failed to place order: {e}")
            raise

    def get_account_info(self) -> Dict[str, Any]:
        """Get account information."""
        try:
            data = self._make_request_sync("account", authenticated=True)
            return data
        except Exception as e:
            logger.error(f"Failed to get account info: {e}")
            raise

    def get_order_history(
        self, symbol: str = None, limit: int = 100
    ) -> List[Dict[str, Any]]:
        """Get order history."""
        params = {"limit": limit}
        if symbol:
            params["symbol"] = symbol

        try:
            data = self._make_request_sync("orders", params, authenticated=True)
            return data.get("orders", [])
        except Exception as e:
            logger.error(f"Failed to get order history: {e}")
            raise

    def _interpolate_candles(
        self,
        raw_data: pd.DataFrame,
        target_timeframe: str,
        start_date: datetime,
        end_date: datetime,
    ) -> pd.DataFrame:
        """
        Interpolate candle data to create non-native timeframes.

        Args:
            raw_data: Source candle data (higher frequency)
            target_timeframe: Target timeframe to create
            start_date: Start of requested period
            end_date: End of requested period

        Returns:
            DataFrame with interpolated candle data
        """
        try:
            if raw_data.empty:
                return pd.DataFrame()

            # Define interpolation rules
            interpolation_map = {
                "5m": ("1m", 5),  # 5m from 1m data
                "30m": ("15m", 2),  # 30m from 15m data
                "4h": ("1h", 4),  # 4h from 1h data
            }

            if target_timeframe not in interpolation_map:
                raise ValueError(f"Interpolation not supported for {target_timeframe}")

            source_tf, multiplier = interpolation_map[target_timeframe]

            # Resample to target timeframe
            # OHLCV aggregation rules:
            # - Open: first value in period
            # - High: maximum value in period
            # - Low: minimum value in period
            # - Close: last value in period
            # - Volume: sum of volumes in period

            agg_rules = {
                "open": "first",
                "high": "max",
                "low": "min",
                "close": "last",
                "volume": "sum",
            }

            # Create resampling frequency string
            freq_map = {
                "5m": "5min",  # 5 minutes
                "30m": "30min",  # 30 minutes
                "4h": "4H",  # 4 hours
            }

            freq = freq_map.get(target_timeframe)
            if not freq:
                raise ValueError(f"No frequency mapping for {target_timeframe}")

            # Resample the data
            resampled = raw_data.resample(freq).agg(agg_rules)

            # Remove rows with NaN values (incomplete periods)
            resampled = resampled.dropna()

            # Filter to requested date range
            mask = (resampled.index >= start_date) & (resampled.index <= end_date)
            result = resampled[mask]

            logger.info(
                f"Interpolated {len(raw_data)} {source_tf} candles to {len(result)} {target_timeframe} candles"
            )

            return result

        except Exception as e:
            logger.error(f"Failed to interpolate candles: {e}")
            return pd.DataFrame()

    def _expand_start_date_to_month_start(self, date: datetime) -> datetime:
        """
        Expande a data inicial para o início do mês para melhor cache.

        Args:
            date: Data original

        Returns:
            Data expandida para início do mês
        """
        return date.replace(day=1, hour=0, minute=0, second=0, microsecond=0)

    def _expand_end_date_to_month_end(self, date: datetime) -> datetime:
        """
        Expande a data final para o final do mês para melhor cache.

        Args:
            date: Data original

        Returns:
            Data expandida para fim do mês
        """
        # Próximo mês, dia 1
        if date.month == 12:
            next_month = date.replace(year=date.year + 1, month=1, day=1)
        else:
            next_month = date.replace(month=date.month + 1, day=1)

        # Último segundo do mês atual
        return next_month - timedelta(seconds=1)

    def _is_cache_complete(
        self,
        data: pd.DataFrame,
        start_date: datetime,
        end_date: datetime,
        timeframe: str,
    ) -> bool:
        """
        Verifica se o cache está completo para o período solicitado.

        Args:
            data: Dados do cache
            start_date: Data inicial solicitada
            end_date: Data final solicitada
            timeframe: Timeframe dos dados

        Returns:
            True se o cache está completo
        """
        if data.empty:
            return False

        # Verificar cobertura temporal
        data_start = data.index.min()
        data_end = data.index.max()

        # Tolerância baseada no timeframe
        tolerance_map = {
            "1m": timedelta(minutes=5),
            "5m": timedelta(minutes=15),
            "15m": timedelta(minutes=30),
            "30m": timedelta(hours=1),
            "1h": timedelta(hours=2),
            "3h": timedelta(hours=6),
            "4h": timedelta(hours=8),
            "1d": timedelta(days=1),
            "1w": timedelta(days=2),
            "1M": timedelta(days=3),
        }

        tolerance = tolerance_map.get(timeframe, timedelta(hours=1))

        # Verificar se cobrimos o período solicitado (com tolerância)
        coverage_start = data_start <= (start_date + tolerance)
        coverage_end = data_end >= (end_date - tolerance)

        if not (coverage_start and coverage_end):
            logger.debug(
                f"Cache coverage insufficient: data [{data_start} - {data_end}], requested [{start_date} - {end_date}]"
            )
            return False

        # Verificar densidade (pelo menos 70% dos candles esperados)
        expected_candles = self._calculate_expected_candles(
            timeframe, start_date, end_date
        )
        actual_candles = len(data)
        density = (
            (actual_candles / expected_candles) * 100 if expected_candles > 0 else 0
        )

        if density < 70:
            logger.debug(
                f"Cache density insufficient: {density:.1f}% ({actual_candles}/{expected_candles})"
            )
            return False

        return True

    def _is_data_complete_for_caching(
        self,
        data: pd.DataFrame,
        start_date: datetime,
        end_date: datetime,
        timeframe: str,
    ) -> bool:
        """
        Verifica se os dados estão completos o suficiente para cache.

        Args:
            data: Dados a serem verificados
            start_date: Data inicial do período
            end_date: Data final do período
            timeframe: Timeframe dos dados

        Returns:
            True se os dados estão completos para cache
        """
        if data.empty:
            return False

        # Para o mês atual, sempre permitir cache (dados parciais são esperados)
        current_month_start = datetime.now().replace(
            day=1, hour=0, minute=0, second=0, microsecond=0
        )
        is_current_month = start_date >= current_month_start

        if is_current_month:
            logger.debug("Current month data, allowing cache even if partial")
            return True

        # Para meses completos, verificar densidade mínima de 80%
        expected_candles = self._calculate_expected_candles(
            timeframe, start_date, end_date
        )
        actual_candles = len(data)
        density = (
            (actual_candles / expected_candles) * 100 if expected_candles > 0 else 0
        )

        min_density = 80.0
        is_complete = density >= min_density

        if not is_complete:
            logger.debug(
                f"Data incomplete for caching: {density:.1f}% < {min_density}% ({actual_candles}/{expected_candles})"
            )

        return is_complete

    def _calculate_expected_candles(
        self, timeframe: str, start_date: datetime, end_date: datetime
    ) -> int:
        """
        Calcula número esperado de candles para um período.

        Args:
            timeframe: Timeframe
            start_date: Data inicial
            end_date: Data final

        Returns:
            Número esperado de candles
        """
        interval_minutes = {
            "1m": 1,
            "5m": 5,
            "15m": 15,
            "30m": 30,
            "1h": 60,
            "3h": 180,
            "4h": 240,
            "1d": 1440,
            "1w": 10080,  # 7 * 24 * 60
            "1M": 43200,  # Aproximado: 30 * 24 * 60
        }

        if timeframe not in interval_minutes:
            logger.warning(f"Unknown timeframe {timeframe}, using 1h default")
            return 0

        total_minutes = (end_date - start_date).total_seconds() / 60
        expected = int(total_minutes / interval_minutes[timeframe])

        return max(0, expected)

    def _validate_countback(self, countback: int) -> None:
        """
        Validate countback parameter.

        Args:
            countback: Number of periods to validate

        Raises:
            ValueError: If countback is invalid
        """
        if not isinstance(countback, int):
            raise ValueError(
                f"Invalid countback: must be integer, got {type(countback).__name__}"
            )

        if countback <= 0:
            raise ValueError(f"Invalid countback: must be positive, got {countback}")

        if countback > 5000:
            raise ValueError(
                f"Invalid countback: maximum allowed is 5000, got {countback}"
            )

    def _fetch_candles_with_countback(
        self, symbol: str, timeframe: str, countback: int, to_timestamp: int
    ) -> pd.DataFrame:
        """
        Fetch candle data using countback approach.

        Args:
            symbol: Trading symbol
            timeframe: Data timeframe
            countback: Number of periods to look back
            to_timestamp: End timestamp

        Returns:
            DataFrame with OHLCV data
        """
        try:
            # Check if timeframe needs interpolation
            native_timeframes = ["1m", "15m", "1h", "3h", "1d", "1w", "1M"]
            interpolated_timeframes = {
                "5m": ("1m", 5),
                "30m": ("15m", 2),
                "4h": ("1h", 4),
            }

            if timeframe in interpolated_timeframes:
                # Use interpolation for non-native timeframes
                source_tf, multiplier = interpolated_timeframes[timeframe]
                logger.info(
                    f"Using interpolation for countback: {timeframe} from {source_tf} data (factor: {multiplier})"
                )

                # Fetch more data to ensure we have enough for interpolation
                extended_countback = countback * multiplier + 100  # Extra buffer
                raw_data = self._fetch_native_candles_with_countback(
                    symbol, source_tf, extended_countback, to_timestamp
                )

                if raw_data.empty:
                    return pd.DataFrame()

                # Apply interpolation and return last 'countback' candles
                interpolated_data = self._interpolate_candles_for_countback(
                    raw_data, timeframe
                )
                return (
                    interpolated_data.tail(countback)
                    if len(interpolated_data) >= countback
                    else interpolated_data
                )

            elif timeframe in native_timeframes:
                # Direct API call for native timeframes
                return self._fetch_native_candles_with_countback(
                    symbol, timeframe, countback, to_timestamp
                )

            else:
                raise ValueError(f"Unsupported timeframe: {timeframe}")

        except Exception as e:
            logger.error(f"Failed to fetch candles with countback: {e}")
            raise

    def _fetch_native_candles_with_countback(
        self, symbol: str, timeframe: str, countback: int, to_timestamp: int
    ) -> pd.DataFrame:
        """
        Fetch candle data with countback from MB API for native timeframes.
        """
        try:
            # MB API timeframe mapping
            api_timeframe_map = {
                "1m": "1m",
                "15m": "15m",
                "1h": "1h",
                "3h": "3h",
                "1d": "1d",
                "1w": "1w",
                "1M": "1M",
            }

            api_timeframe = api_timeframe_map.get(timeframe)
            if not api_timeframe:
                raise ValueError(f"Non-native timeframe: {timeframe}")

            params = {
                "symbol": symbol,
                "resolution": api_timeframe,
                "countback": countback,
                "to": to_timestamp,
            }

            data = self._make_request_sync(
                endpoint="candles",
                method="GET", 
                params=params,
                authenticated=False
            )

            # Handle Mercado Bitcoin API v4 candles format
            if isinstance(data, dict) and all(
                key in data for key in ["t", "o", "h", "l", "c", "v"]
            ):
                timestamps = data.get("t", [])
                if not timestamps:
                    logger.warning(
                        f"No candle data returned for {symbol} {timeframe} countback={countback}"
                    )
                    return pd.DataFrame()

                # Create DataFrame from individual arrays
                df = pd.DataFrame(
                    {
                        "timestamp": timestamps,
                        "open": data.get("o", []),
                        "high": data.get("h", []),
                        "low": data.get("l", []),
                        "close": data.get("c", []),
                        "volume": data.get("v", []),
                    }
                )
            else:
                # Fallback to original format
                candles = data.get("candles", [])
                if not candles:
                    logger.warning(
                        f"No candle data returned for {symbol} {timeframe} countback={countback}"
                    )
                    return pd.DataFrame()

                # Convert to DataFrame
                df = pd.DataFrame(candles)

            # Ensure numeric types and handle missing data
            numeric_columns = ["open", "high", "low", "close", "volume"]
            for col in numeric_columns:
                if col in df.columns:
                    df[col] = pd.to_numeric(df[col], errors="coerce")

            # Convert timestamp to datetime index
            if "timestamp" in df.columns:
                df["timestamp"] = pd.to_datetime(df["timestamp"], unit="s")
                df.set_index("timestamp", inplace=True)

            # Remove any rows with NaN values
            df = df.dropna()

            # Sort by timestamp to ensure correct order
            df = df.sort_index()

            logger.info(
                f"Retrieved {len(df)} candles for {symbol} {timeframe} (countback={countback})"
            )
            return df

        except Exception as e:
            logger.error(f"Failed to fetch native candles with countback: {e}")
            raise

    def _interpolate_candles_for_countback(
        self, data: pd.DataFrame, target_timeframe: str
    ) -> pd.DataFrame:
        """
        Interpolate candles for countback (simplified version).

        Args:
            data: Source DataFrame
            target_timeframe: Target timeframe

        Returns:
            Interpolated DataFrame
        """
        # This is a simplified version for countback
        # For now, just resample the data to the target timeframe
        timeframe_map = {"5m": "5min", "30m": "30min", "4h": "4H"}

        freq = timeframe_map.get(target_timeframe)
        if not freq:
            return data

        # Resample using OHLCV aggregation
        resampled = (
            data.resample(freq)
            .agg(
                {
                    "open": "first",
                    "high": "max",
                    "low": "min",
                    "close": "last",
                    "volume": "sum",
                }
            )
            .dropna()
        )

        return resampled
