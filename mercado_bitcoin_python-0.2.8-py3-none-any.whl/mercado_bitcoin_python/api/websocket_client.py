"""
WebSocket client for Mercado Bitcoin with keep-alive support.

Note: Mercado Bitcoin WebSockets close after 5 seconds of inactivity.
This client implements automatic keep-alive to maintain connection.
"""

import asyncio
import json
import time
import websockets
from typing import Dict, Any, Callable, Optional, List
from dataclasses import dataclass
from loguru import logger

from ..exceptions.api_exceptions import WebSocketError


@dataclass
class WSConfig:
    """WebSocket configuration."""

    url: str = "wss://ws.mercadobitcoin.net/ws"
    ping_interval: int = 4  # Send ping every 4 seconds (MB closes after 5s idle)
    reconnect_delay: int = 5
    max_reconnect_attempts: int = 10
    message_queue_size: int = 1000


class WebSocketClient:
    """
    WebSocket client with automatic keep-alive and reconnection.

    Features:
    - Automatic keep-alive (ping every 4 seconds)
    - Automatic reconnection on disconnect
    - Message queuing
    - Event callbacks
    - Error handling
    """

    def __init__(self, config: WSConfig = None):
        """
        Initialize WebSocket client.

        Args:
            config: WebSocket configuration
        """
        self.config = config or WSConfig()
        self.websocket: Optional[websockets.WebSocketServerProtocol] = None
        self.is_connected = False
        self.is_running = False
        self.reconnect_count = 0

        # Event callbacks
        self.on_message: Optional[Callable[[Dict[str, Any]], None]] = None
        self.on_connect: Optional[Callable[[], None]] = None
        self.on_disconnect: Optional[Callable[[], None]] = None
        self.on_error: Optional[Callable[[Exception], None]] = None

        # Subscription management
        self.subscriptions: List[Dict[str, Any]] = []

        # Keep-alive task
        self._ping_task: Optional[asyncio.Task] = None
        self._listen_task: Optional[asyncio.Task] = None
        self._reconnect_task: Optional[asyncio.Task] = None

        logger.info(
            f"WebSocket client initialized (ping_interval: {self.config.ping_interval}s)"
        )

    async def connect(self) -> None:
        """Connect to WebSocket."""
        try:
            logger.info(f"Connecting to WebSocket: {self.config.url}")

            self.websocket = await websockets.connect(
                self.config.url,
                ping_interval=None,  # We handle ping manually
                ping_timeout=None,
                close_timeout=10,
            )

            self.is_connected = True
            self.reconnect_count = 0

            logger.info("WebSocket connected successfully")

            # Start keep-alive and listening tasks
            self._ping_task = asyncio.create_task(self._keep_alive_loop())
            self._listen_task = asyncio.create_task(self._listen_loop())

            # Resubscribe to channels after reconnection
            await self._resubscribe()

            # Call connect callback
            if self.on_connect:
                try:
                    self.on_connect()
                except Exception as e:
                    logger.error(f"Error in on_connect callback: {e}")

        except Exception as e:
            logger.error(f"Failed to connect to WebSocket: {e}")
            self.is_connected = False
            raise WebSocketError(f"Connection failed: {e}")

    async def disconnect(self) -> None:
        """Disconnect from WebSocket."""
        logger.info("Disconnecting WebSocket...")

        self.is_running = False
        self.is_connected = False

        # Cancel tasks
        if self._ping_task and not self._ping_task.done():
            self._ping_task.cancel()
        if self._listen_task and not self._listen_task.done():
            self._listen_task.cancel()
        if self._reconnect_task and not self._reconnect_task.done():
            self._reconnect_task.cancel()

        # Close WebSocket connection
        if self.websocket and not self.websocket.closed:
            await self.websocket.close()

        # Call disconnect callback
        if self.on_disconnect:
            try:
                self.on_disconnect()
            except Exception as e:
                logger.error(f"Error in on_disconnect callback: {e}")

        logger.info("WebSocket disconnected")

    async def start(self) -> None:
        """Start WebSocket client with automatic reconnection."""
        self.is_running = True

        while self.is_running:
            try:
                if not self.is_connected:
                    await self.connect()

                # Wait for connection to close or error
                if self._listen_task:
                    await self._listen_task

            except Exception as e:
                logger.error(f"WebSocket error: {e}")

                if self.on_error:
                    try:
                        self.on_error(e)
                    except Exception as callback_error:
                        logger.error(f"Error in on_error callback: {callback_error}")

                if (
                    self.is_running
                    and self.reconnect_count < self.config.max_reconnect_attempts
                ):
                    self.reconnect_count += 1
                    logger.info(
                        f"Attempting reconnect {self.reconnect_count}/{self.config.max_reconnect_attempts}"
                    )
                    await asyncio.sleep(self.config.reconnect_delay)
                else:
                    logger.error("Max reconnection attempts reached")
                    break

    async def _keep_alive_loop(self) -> None:
        """Keep-alive loop to prevent connection timeout."""
        while self.is_connected and self.is_running:
            try:
                if self.websocket and not self.websocket.closed:
                    # Send ping to keep connection alive
                    ping_message = {
                        "id": int(time.time() * 1000),
                        "method": "ping",
                        "params": {},
                    }

                    await self.websocket.send(json.dumps(ping_message))
                    logger.debug("Sent keep-alive ping")

                await asyncio.sleep(self.config.ping_interval)

            except websockets.exceptions.ConnectionClosed:
                logger.warning("WebSocket connection closed during keep-alive")
                self.is_connected = False
                break
            except Exception as e:
                logger.error(f"Error in keep-alive loop: {e}")
                await asyncio.sleep(1)

    async def _listen_loop(self) -> None:
        """Listen for incoming messages."""
        while self.is_connected and self.is_running:
            try:
                if self.websocket and not self.websocket.closed:
                    message = await self.websocket.recv()
                    await self._handle_message(message)
                else:
                    break

            except websockets.exceptions.ConnectionClosed:
                logger.warning("WebSocket connection closed")
                self.is_connected = False
                break
            except Exception as e:
                logger.error(f"Error in listen loop: {e}")
                self.is_connected = False
                break

    async def _handle_message(self, message: str) -> None:
        """Handle incoming WebSocket message."""
        try:
            data = json.loads(message)

            # Handle different message types
            if data.get("method") == "pong":
                logger.debug("Received pong response")
                return

            # Call message callback
            if self.on_message:
                try:
                    self.on_message(data)
                except Exception as e:
                    logger.error(f"Error in on_message callback: {e}")

        except json.JSONDecodeError:
            logger.error(f"Failed to decode WebSocket message: {message}")
        except Exception as e:
            logger.error(f"Error handling WebSocket message: {e}")

    async def subscribe_ticker(self, symbol: str) -> None:
        """
        Subscribe to ticker updates for a symbol.

        Args:
            symbol: Trading symbol (e.g., 'BRLBTC')
        """
        subscription = {
            "id": int(time.time() * 1000),
            "method": "subscribe_ticker",
            "params": {"symbol": symbol},
        }

        await self._send_subscription(subscription)

    async def subscribe_orderbook(self, symbol: str) -> None:
        """
        Subscribe to order book updates for a symbol.

        Args:
            symbol: Trading symbol (e.g., 'BRLBTC')
        """
        subscription = {
            "id": int(time.time() * 1000),
            "method": "subscribe_orderbook",
            "params": {"symbol": symbol},
        }

        await self._send_subscription(subscription)

    async def subscribe_trades(self, symbol: str) -> None:
        """
        Subscribe to trade updates for a symbol.

        Args:
            symbol: Trading symbol (e.g., 'BRLBTC')
        """
        subscription = {
            "id": int(time.time() * 1000),
            "method": "subscribe_trades",
            "params": {"symbol": symbol},
        }

        await self._send_subscription(subscription)

    async def _send_subscription(self, subscription: Dict[str, Any]) -> None:
        """Send subscription message and store for reconnection."""
        try:
            if self.websocket and not self.websocket.closed and self.is_connected:
                await self.websocket.send(json.dumps(subscription))

                # Store subscription for reconnection
                self.subscriptions.append(subscription)
                logger.info(
                    f"Subscribed to {subscription['method']}: {subscription['params']}"
                )
            else:
                logger.warning("Cannot send subscription: WebSocket not connected")

        except Exception as e:
            logger.error(f"Failed to send subscription: {e}")
            raise WebSocketError(f"Subscription failed: {e}")

    async def _resubscribe(self) -> None:
        """Resubscribe to all channels after reconnection."""
        if self.subscriptions:
            logger.info(f"Resubscribing to {len(self.subscriptions)} channels")

            for subscription in self.subscriptions:
                try:
                    # Update subscription ID
                    subscription["id"] = int(time.time() * 1000)

                    if self.websocket and not self.websocket.closed:
                        await self.websocket.send(json.dumps(subscription))
                        logger.debug(f"Resubscribed to {subscription['method']}")

                        # Small delay between subscriptions
                        await asyncio.sleep(0.1)

                except Exception as e:
                    logger.error(
                        f"Failed to resubscribe to {subscription['method']}: {e}"
                    )

    async def unsubscribe_all(self) -> None:
        """Unsubscribe from all channels."""
        self.subscriptions.clear()

        if self.websocket and not self.websocket.closed and self.is_connected:
            unsubscribe_message = {
                "id": int(time.time() * 1000),
                "method": "unsubscribe_all",
                "params": {},
            }

            try:
                await self.websocket.send(json.dumps(unsubscribe_message))
                logger.info("Unsubscribed from all channels")
            except Exception as e:
                logger.error(f"Failed to unsubscribe from all channels: {e}")


# Example usage
async def example_websocket_usage():
    """Example of how to use the WebSocket client."""

    def on_message(data):
        print(f"Received: {data}")

    def on_connect():
        print("Connected to WebSocket")

    def on_disconnect():
        print("Disconnected from WebSocket")

    def on_error(error):
        print(f"WebSocket error: {error}")

    # Create client
    client = WebSocketClient()

    # Set callbacks
    client.on_message = on_message
    client.on_connect = on_connect
    client.on_disconnect = on_disconnect
    client.on_error = on_error

    try:
        # Connect and subscribe
        await client.connect()
        await client.subscribe_ticker("BRLBTC")
        await client.subscribe_orderbook("BRLBTC")

        # Start client (this will run indefinitely with auto-reconnect)
        await client.start()

    except KeyboardInterrupt:
        print("Shutting down...")
        await client.disconnect()


if __name__ == "__main__":
    asyncio.run(example_websocket_usage())
