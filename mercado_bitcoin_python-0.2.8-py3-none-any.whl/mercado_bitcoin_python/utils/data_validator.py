"""
Data validation utilities for market data.
"""

import pandas as pd
from typing import List, Optional
from loguru import logger

from ..exceptions.api_exceptions import DataValidationError


class DataValidator:
    """
    Validates market data for consistency and completeness.
    """

    @staticmethod
    def validate_ohlcv_data(
        data: pd.DataFrame, symbol: str = "", strict: bool = False
    ) -> bool:
        """
        Validate OHLCV data structure and values.

        Args:
            data: DataFrame to validate
            symbol: Trading symbol for logging
            strict: If True, raise exceptions on validation errors

        Returns:
            True if valid, False if invalid (when strict=False)

        Raises:
            DataValidationError: When strict=True and validation fails
        """
        issues = []

        # Check if DataFrame is empty
        if data.empty:
            issues.append("DataFrame is empty")

        # Check required columns
        required_columns = ["open", "high", "low", "close", "volume"]
        missing_columns = [col for col in required_columns if col not in data.columns]
        if missing_columns:
            issues.append(f"Missing columns: {missing_columns}")

        if not issues and not data.empty:
            # Check for NaN values
            nan_columns = (
                data[required_columns]
                .columns[data[required_columns].isnull().any()]
                .tolist()
            )
            if nan_columns:
                issues.append(f"NaN values found in columns: {nan_columns}")

            # Check OHLC relationships
            invalid_ohlc = (
                (data["high"] < data["low"])
                | (data["high"] < data["open"])
                | (data["high"] < data["close"])
                | (data["low"] > data["open"])
                | (data["low"] > data["close"])
            )

            if invalid_ohlc.any():
                invalid_count = invalid_ohlc.sum()
                issues.append(f"Invalid OHLC relationships in {invalid_count} rows")

            # Check for negative values
            negative_volume = (data["volume"] < 0).any()
            if negative_volume:
                issues.append("Negative volume values found")

            negative_prices = (
                (data["open"] <= 0).any()
                | (data["high"] <= 0).any()
                | (data["low"] <= 0).any()
                | (data["close"] <= 0).any()
            )
            if negative_prices:
                issues.append("Non-positive price values found")

            # Check for duplicate timestamps
            if data.index.duplicated().any():
                duplicate_count = data.index.duplicated().sum()
                issues.append(f"Duplicate timestamps: {duplicate_count} rows")

        # Handle validation results
        if issues:
            error_msg = f"Data validation failed for {symbol}: {'; '.join(issues)}"
            logger.warning(error_msg)

            if strict:
                raise DataValidationError(error_msg)
            return False

        logger.debug(f"Data validation passed for {symbol}: {len(data)} rows")
        return True

    @staticmethod
    def validate_timeframe_consistency(
        data: pd.DataFrame, timeframe: str, tolerance_pct: float = 10.0
    ) -> bool:
        """
        Validate that data timestamps are consistent with the specified timeframe.

        Args:
            data: DataFrame with timestamp index
            timeframe: Expected timeframe (e.g., '5m', '1h', '1d')
            tolerance_pct: Allowed percentage of intervals that can be inconsistent

        Returns:
            True if consistent, False otherwise
        """
        if data.empty or len(data) < 2:
            return True

        # Map timeframes to expected intervals in minutes
        timeframe_minutes = {
            "1m": 1,
            "5m": 5,
            "15m": 15,
            "30m": 30,
            "1h": 60,
            "4h": 240,
            "1d": 1440,
            "1w": 10080,
        }

        expected_interval = timeframe_minutes.get(timeframe)
        if not expected_interval:
            logger.warning(f"Unknown timeframe for validation: {timeframe}")
            return True

        # Calculate actual intervals between timestamps
        time_diffs = data.index.to_series().diff().dt.total_seconds() / 60
        time_diffs = time_diffs.dropna()

        if len(time_diffs) == 0:
            return True

        # Check how many intervals match the expected timeframe
        # Allow some tolerance for weekend gaps, holidays, etc.
        matching_intervals = (
            (time_diffs >= expected_interval * 0.9)
            & (time_diffs <= expected_interval * 1.1)
        ).sum()

        consistency_pct = (matching_intervals / len(time_diffs)) * 100

        if consistency_pct < (100 - tolerance_pct):
            logger.warning(
                f"Timeframe consistency below threshold: {consistency_pct:.1f}% "
                f"(expected: {100-tolerance_pct:.1f}%)"
            )
            return False

        logger.debug(f"Timeframe consistency: {consistency_pct:.1f}%")
        return True

    @staticmethod
    def clean_data(
        data: pd.DataFrame,
        remove_duplicates: bool = True,
        fill_missing: bool = False,
        validate_ohlc: bool = True,
    ) -> pd.DataFrame:
        """
        Clean and prepare market data.

        Args:
            data: DataFrame to clean
            remove_duplicates: Remove duplicate timestamps
            fill_missing: Fill missing values using forward fill
            validate_ohlc: Validate OHLC relationships

        Returns:
            Cleaned DataFrame
        """
        cleaned_data = data.copy()

        # Remove duplicates
        if remove_duplicates and cleaned_data.index.duplicated().any():
            original_count = len(cleaned_data)
            cleaned_data = cleaned_data[~cleaned_data.index.duplicated(keep="last")]
            logger.info(f"Removed {original_count - len(cleaned_data)} duplicate rows")

        # Fill missing values
        if fill_missing and cleaned_data.isnull().any().any():
            cleaned_data = cleaned_data.fillna(method="ffill")
            logger.info("Filled missing values using forward fill")

        # Sort by timestamp
        cleaned_data = cleaned_data.sort_index()

        # Validate OHLC if requested
        if validate_ohlc:
            DataValidator.validate_ohlcv_data(cleaned_data, strict=False)

        return cleaned_data
