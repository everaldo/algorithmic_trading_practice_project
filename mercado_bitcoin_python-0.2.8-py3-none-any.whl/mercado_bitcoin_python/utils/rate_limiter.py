"""
Rate limiter for Mercado Bitcoin API with endpoint-specific limits.
"""

import asyncio
import time
from typing import Optional, Dict
from loguru import logger


class RateLimiter:
    """
    Rate limiter for Mercado Bitcoin API with endpoint-specific limits.

    Default: 60 requests per 60 seconds (1 req/s)
    Different endpoints may have different limits.

    Features:
    - Thread-safe operation
    - Async/await support
    - Endpoint-specific rate limiting
    - Request timing statistics
    """

    def __init__(self, requests_per_minute: int = 60):
        """
        Initialize rate limiter.

        Args:
            requests_per_minute: Maximum requests per minute (default: 60 for MB API)
        """
        self.requests_per_minute = requests_per_minute
        self.requests_per_second = requests_per_minute / 60.0
        self.interval = 60.0 / requests_per_minute
        self.last_request_time: Optional[float] = None
        self._lock = asyncio.Lock()
        self.request_count = 0
        self.request_history: list = []  # Track requests in last minute

        # Endpoint-specific limits based on official MB API v4 documentation
        # Default total: 500 requests/min
        self.endpoint_limits: Dict[str, float] = {
            # Public endpoints - 1 req/sec
            "symbols": 1.0,
            "candles": 1.0,
            "tickers": 1.0,
            "trades": 1.0,  # /{symbol}/trades
            "orderbook": 1.0,  # /{symbol}/orderbook
            "fees": 1.0,  # /{asset}/fees
            "networks": 1.0,  # /{asset}/networks
            # Private endpoints - Account related
            "accounts/balances": 3.0,  # /accounts/{accountId}/balances
            "accounts/positions": 1.0,  # /accounts/{accountId}/positions
            "accounts/orders": 3.0,  # /accounts/{accountId}/orders (all markets)
            # Private endpoints - Trading
            "orders/list": 10.0,  # /accounts/{accountId}/{symbol}/orders (list)
            "orders/place": 3.0,  # POST /accounts/{accountId}/{symbol}/orders
            "orders/cancel": 3.0,  # DELETE /accounts/{accountId}/{symbol}/orders/{orderId}
            "orders/get": 1.0,  # GET /accounts/{accountId}/{symbol}/orders/{orderId}
            "orders/cancel_all": 1.0 / 60.0,  # 1 request/min (very restrictive)
            "order": 3.0,  # Generic order endpoint
            "account": 1.0,  # Account info endpoint
            "orders": 3.0,  # Orders history endpoint
        }

        logger.info(
            f"Rate limiter initialized: {requests_per_minute} req/min ({self.requests_per_second:.2f} req/s)"
        )

    def get_endpoint_limit(self, endpoint: str) -> float:
        """
        Get rate limit for specific endpoint.

        Args:
            endpoint: API endpoint path

        Returns:
            Requests per second limit for the endpoint
        """
        # Try exact match first
        if endpoint in self.endpoint_limits:
            return self.endpoint_limits[endpoint]

        # Try partial matches for dynamic endpoints
        for pattern, limit in self.endpoint_limits.items():
            if (
                pattern.replace("{symbol}", "")
                .replace("{asset}", "")
                .replace("{accountId}", "")
                .replace("{orderId}", "")
                in endpoint
            ):
                return limit

        # Default to conservative 1 req/s if not found
        return 1.0

    async def acquire(self, endpoint: str = None) -> None:
        """
        Acquire permission to make a request.

        Args:
            endpoint: Specific endpoint to get rate limit for

        This method will block until it's safe to make the next request
        according to the rate limit.
        """
        # Get endpoint-specific limit
        if endpoint:
            endpoint_limit = self.get_endpoint_limit(endpoint)
            interval = 1.0 / endpoint_limit
        else:
            interval = self.interval

        async with self._lock:
            current_time = time.time()

            # Clean old requests from history (older than 1 minute)
            cutoff_time = current_time - 60
            self.request_history = [t for t in self.request_history if t > cutoff_time]

            # Check if we're approaching the total limit (500 req/min)
            if len(self.request_history) >= (
                self.requests_per_minute * 0.9
            ):  # 90% of limit
                sleep_time = 60 - (current_time - self.request_history[0])
                if sleep_time > 0:
                    logger.warning(
                        f"Approaching total rate limit, waiting {sleep_time:.2f}s"
                    )
                    await asyncio.sleep(sleep_time)
                    current_time = time.time()

            # Apply endpoint-specific rate limiting
            if self.last_request_time is not None:
                time_since_last = current_time - self.last_request_time
                if time_since_last < interval:
                    sleep_time = interval - time_since_last
                    logger.debug(
                        f"Rate limit: waiting {sleep_time:.2f}s for {endpoint or 'default'}"
                    )
                    await asyncio.sleep(sleep_time)
                    current_time = time.time()

            self.last_request_time = current_time
            self.request_count += 1
            self.request_history.append(current_time)

            logger.debug(
                f"Rate limit: request {self.request_count} allowed for {endpoint or 'default'} "
                f"(limit: {self.get_endpoint_limit(endpoint) if endpoint else self.requests_per_second:.1f} req/s)"
            )

            # Log usage statistics
            if self.request_count % 50 == 0:
                logger.info(
                    f"Rate limiter stats: {len(self.request_history)} requests in last minute "
                    f"(limit: {self.requests_per_minute})"
                )

    def acquire_sync(self, endpoint: str = None) -> None:
        """
        Synchronous version of acquire for non-async code.

        Args:
            endpoint: Specific endpoint to get rate limit for
        """
        # Get endpoint-specific limit
        if endpoint:
            endpoint_limit = self.get_endpoint_limit(endpoint)
            interval = 1.0 / endpoint_limit
        else:
            interval = self.interval

        current_time = time.time()

        # Clean old requests from history (older than 1 minute)
        cutoff_time = current_time - 60
        self.request_history = [t for t in self.request_history if t > cutoff_time]

        # Check if we're approaching the total limit (500 req/min)
        if len(self.request_history) >= (
            self.requests_per_minute * 0.9
        ):  # 90% of limit
            sleep_time = 60 - (current_time - self.request_history[0])
            if sleep_time > 0:
                logger.warning(
                    f"Approaching total rate limit, waiting {sleep_time:.2f}s"
                )
                time.sleep(sleep_time)
                current_time = time.time()

        # Apply endpoint-specific rate limiting
        if self.last_request_time is not None:
            time_since_last = current_time - self.last_request_time
            if time_since_last < interval:
                sleep_time = interval - time_since_last
                logger.debug(
                    f"Rate limit: waiting {sleep_time:.2f}s for {endpoint or 'default'}"
                )
                time.sleep(sleep_time)
                current_time = time.time()

        self.last_request_time = current_time
        self.request_count += 1
        self.request_history.append(current_time)

        logger.debug(
            f"Rate limit: request {self.request_count} allowed for {endpoint or 'default'} "
            f"(limit: {self.get_endpoint_limit(endpoint) if endpoint else self.requests_per_second:.1f} req/s)"
        )

        # Log usage statistics
        if self.request_count % 50 == 0:
            logger.info(
                f"Rate limiter stats: {len(self.request_history)} requests in last minute "
                f"(limit: {self.requests_per_minute})"
            )

    def reset_stats(self) -> None:
        """Reset request statistics."""
        self.request_count = 0
        self.last_request_time = None
        logger.debug("Rate limiter statistics reset")

    @property
    def stats(self) -> dict:
        """Get rate limiter statistics."""
        return {
            "requests_per_second": self.requests_per_second,
            "interval": self.interval,
            "total_requests": self.request_count,
            "last_request_time": self.last_request_time,
        }
